@extends('admin.layouts.app')
@section('title', 'Login Activity Log')

@push('styles')
<style>
/* ── Page Header ── */
.page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 12px; }
.page-header-left h1 { font-size: 22px; font-weight: 700; color: #1e293b; margin-bottom: 4px; }
.page-header-left p { font-size: 13px; color: #64748b; }
.page-header-right { display: flex; gap: 8px; flex-wrap: wrap; }

/* ── Buttons ── */
.btn { padding: 9px 16px; border-radius: 8px; font-size: 13px; font-weight: 500; cursor: pointer; border: none; display: inline-flex; align-items: center; gap: 6px; text-decoration: none; transition: all .15s; }
.btn-primary { background: #dc2626; color: #fff; }
.btn-primary:hover { background: #b91c1c; }
.btn-secondary { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }
.btn-secondary:hover { background: #e2e8f0; }
.btn-outline { background: transparent; color: #475569; border: 1px solid #d1d5db; }
.btn-outline:hover { background: #f8fafc; border-color: #94a3b8; }
.btn-danger { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
.btn-danger:hover { background: #fee2e2; }
.btn-sm { padding: 6px 10px; font-size: 12px; }
.btn-icon-sm { width: 30px; height: 30px; border-radius: 6px; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 13px; transition: all .15s; }

/* ── Alert ── */
.alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; font-size: 14px; display: flex; align-items: center; gap: 8px; }
.alert-success { background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0; }
.alert-danger { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }

/* ── Stats Row ── */
.stats-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; margin-bottom: 20px; }
@media(max-width:1200px) { .stats-row { grid-template-columns: repeat(3, 1fr); } }
@media(max-width:640px) { .stats-row { grid-template-columns: repeat(2, 1fr); } }
.stat-card { background: #fff; border-radius: 10px; padding: 16px 20px; border: 1px solid #f1f5f9; transition: all .2s; }
.stat-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,.06); border-color: #e2e8f0; }
.stat-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.stat-icon { width: 38px; height: 38px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 16px; }
.stat-icon.blue { background: #eff6ff; color: #2563eb; }
.stat-icon.green { background: #f0fdf4; color: #16a34a; }
.stat-icon.red { background: #fef2f2; color: #dc2626; }
.stat-icon.amber { background: #fffbeb; color: #d97706; }
.stat-icon.purple { background: #f5f3ff; color: #7c3aed; }
.stat-value { font-size: 24px; font-weight: 700; color: #1e293b; line-height: 1.2; margin-bottom: 2px; }
.stat-label { font-size: 12px; color: #64748b; font-weight: 500; }

/* ── Filter Panel ── */
.filter-panel { background: #fff; border-radius: 10px; border: 1px solid #f1f5f9; margin-bottom: 16px; overflow: hidden; }
.filter-toggle { display: flex; justify-content: space-between; align-items: center; padding: 14px 20px; cursor: pointer; user-select: none; }
.filter-toggle:hover { background: #fafbfc; }
.filter-toggle h3 { font-size: 14px; font-weight: 600; color: #374151; display: flex; align-items: center; gap: 8px; }
.filter-toggle .arrow { transition: transform .2s; color: #94a3b8; font-size: 12px; }
.filter-toggle.open .arrow { transform: rotate(180deg); }
.filter-body { padding: 0 20px 20px; display: none; }
.filter-body.show { display: block; }
.filter-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
@media(max-width:1100px) { .filter-grid { grid-template-columns: repeat(2, 1fr); } }
@media(max-width:640px) { .filter-grid { grid-template-columns: 1fr; } }
.filter-group label { display: block; font-size: 12px; font-weight: 600; color: #64748b; margin-bottom: 5px; text-transform: uppercase; letter-spacing: .3px; }
.filter-group select,
.filter-group input { width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 7px; font-size: 13px; color: #374151; background: #fff; }
.filter-group select:focus,
.filter-group input:focus { outline: none; border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,.08); }
.filter-actions { margin-top: 14px; display: flex; gap: 8px; justify-content: flex-end; }
.active-filters { display: flex; flex-wrap: wrap; gap: 6px; padding: 0 20px 14px; }
.filter-tag { display: inline-flex; align-items: center; gap: 4px; padding: 4px 10px; background: #eff6ff; color: #2563eb; border-radius: 6px; font-size: 12px; font-weight: 500; }
.filter-tag a { color: #2563eb; text-decoration: none; font-weight: 700; margin-left: 2px; }
.filter-tag a:hover { color: #dc2626; }

/* ── Card & Table ── */
.card { background: #fff; border-radius: 12px; border: 1px solid #f1f5f9; overflow: hidden; }
.card:hover { border-color: #e2e8f0; }
.card-head { padding: 16px 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f5f9; }
.card-title { font-size: 14px; font-weight: 600; color: #1e293b; display: flex; align-items: center; gap: 8px; }
.card-title i { color: #94a3b8; font-size: 13px; }
.data-table { width: 100%; border-collapse: collapse; }
.data-table th { text-align: left; padding: 11px 16px; font-size: 11px; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: .4px; background: #fafbfc; border-bottom: 1px solid #f1f5f9; white-space: nowrap; }
.data-table td { padding: 12px 16px; font-size: 13px; color: #374151; border-bottom: 1px solid #f8fafc; }
.data-table tbody tr:hover td { background: #fafbfc; }
.data-table tbody tr.expanded-parent td { background: #f8fafc; border-bottom: none; }
.data-table .expand-icon { color: #94a3b8; font-size: 11px; cursor: pointer; transition: transform .2s; }
.data-table .expanded-parent .expand-icon { transform: rotate(180deg); }

/* ── Status Badges ── */
.badge { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 6px; font-size: 11px; font-weight: 600; white-space: nowrap; }
.badge.green { background: #f0fdf4; color: #16a34a; }
.badge.red { background: #fef2f2; color: #dc2626; }
.badge.blue { background: #eff6ff; color: #2563eb; }
.badge.amber { background: #fffbeb; color: #d97706; }
.badge.gray { background: #f3f4f6; color: #6b7280; }
.badge.purple { background: #f5f3ff; color: #7c3aed; }

.status-dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; }
.status-dot.green { background: #22c55e; }
.status-dot.red { background: #ef4444; }
.status-dot.amber { background: #f59e0b; }
.status-dot.blue { background: #3b82f6; }
.status-dot.gray { background: #9ca3af; }

/* ── Device icons ── */
.device-icon { font-size: 14px; color: #64748b; }

/* ── Detail Row ── */
.detail-row { display: none; }
.detail-row.show { display: table-row; }
.detail-content { padding: 16px 24px 16px 42px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; }
.detail-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
@media(max-width:900px) { .detail-grid { grid-template-columns: repeat(2, 1fr); } }
@media(max-width:600px) { .detail-grid { grid-template-columns: 1fr; } }
.detail-item label { display: block; font-size: 11px; font-weight: 600; color: #94a3b8; text-transform: uppercase; letter-spacing: .3px; margin-bottom: 3px; }
.detail-item span { font-size: 13px; color: #1e293b; font-weight: 500; word-break: break-all; }
.detail-ua { margin-top: 12px; padding: 10px 14px; background: #0f172a; border-radius: 6px; color: #e2e8f0; font-family: 'Courier New', monospace; font-size: 11px; word-break: break-all; line-height: 1.5; }

/* ── Modal ── */
.modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,.5); z-index: 9999; align-items: center; justify-content: center; }
.modal-overlay.show { display: flex; }
.modal { background: #fff; border-radius: 12px; width: 100%; max-width: 480px; max-height: 90vh; overflow-y: auto; }
.modal-header { display: flex; justify-content: space-between; align-items: center; padding: 18px 20px; border-bottom: 1px solid #e2e8f0; }
.modal-header h3 { font-size: 16px; font-weight: 600; color: #1e293b; }
.modal-close { background: none; border: none; font-size: 22px; cursor: pointer; color: #64748b; line-height: 1; }
.modal-close:hover { color: #1e293b; }
.modal-body { padding: 20px; }
.modal-footer { display: flex; justify-content: flex-end; gap: 10px; padding: 16px 20px; border-top: 1px solid #e2e8f0; }
.form-group { margin-bottom: 14px; }
.form-group label { display: block; font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 5px; }
.form-control { width: 100%; padding: 9px 14px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 13px; }
.form-control:focus { outline: none; border-color: #2563eb; }

/* ── Pagination ── */
.pagination-wrap { padding: 16px 20px; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #f1f5f9; }
.pagination-info { font-size: 13px; color: #64748b; }
.pagination-links { display: flex; gap: 4px; }
.pagination-links a,
.pagination-links span { padding: 6px 12px; border-radius: 6px; font-size: 13px; text-decoration: none; border: 1px solid #e2e8f0; color: #374151; }
.pagination-links a:hover { background: #f1f5f9; }
.pagination-links .active span { background: #dc2626; color: #fff; border-color: #dc2626; }
.pagination-links .disabled span { color: #d1d5db; cursor: default; }

/* ── Utilities ── */
.text-muted { color: #94a3b8; }
.text-sm { font-size: 12px; }
.nowrap { white-space: nowrap; }
.empty-state { padding: 60px 20px; text-align: center; color: #94a3b8; }
.empty-state i { font-size: 48px; margin-bottom: 16px; display: block; }
.empty-state p { font-size: 14px; }
</style>
@endpush

@section('content')

{{-- Alerts --}}
@if(session('success'))
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Page Header --}}
<div class="page-header">
    <div class="page-header-left">
        <h1>Login Activity Log</h1>
        <p>Track all admin login sessions, failed attempts, and active connections</p>
    </div>
    <div class="page-header-right">
        <a href="{{ route('admin.admin-log.export', request()->query()) }}" class="btn btn-secondary">
            <i class="fas fa-download"></i> Export CSV
        </a>
        <button class="btn btn-danger" onclick="openPurgeModal()">
            <i class="fas fa-trash-alt"></i> Purge Old
        </button>
    </div>
</div>

{{-- Stats Row --}}
<div class="stats-row">
    <div class="stat-card">
        <div class="stat-top">
            <div class="stat-icon blue"><i class="fas fa-list"></i></div>
        </div>
        <div class="stat-value">{{ number_format($stats['total']) }}</div>
        <div class="stat-label">Total Entries</div>
    </div>
    <div class="stat-card">
        <div class="stat-top">
            <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
        </div>
        <div class="stat-value">{{ number_format($stats['success']) }}</div>
        <div class="stat-label">Successful Logins</div>
    </div>
    <div class="stat-card">
        <div class="stat-top">
            <div class="stat-icon red"><i class="fas fa-times-circle"></i></div>
        </div>
        <div class="stat-value">{{ number_format($stats['failed']) }}</div>
        <div class="stat-label">Failed Attempts</div>
    </div>
    <div class="stat-card">
        <div class="stat-top">
            <div class="stat-icon amber"><i class="fas fa-signal"></i></div>
        </div>
        <div class="stat-value">{{ number_format($stats['active_now']) }}</div>
        <div class="stat-label">Active Now</div>
    </div>
    <div class="stat-card">
        <div class="stat-top">
            <div class="stat-icon purple"><i class="fas fa-network-wired"></i></div>
        </div>
        <div class="stat-value">{{ number_format($stats['unique_ips']) }}</div>
        <div class="stat-label">Unique IPs</div>
    </div>
</div>

{{-- Filter Panel --}}
<div class="filter-panel">
    <div class="filter-toggle {{ request()->hasAny(['status','admin_id','role_id','ip_address','date_from','date_to','device_type','search']) ? 'open' : '' }}" onclick="toggleFilter()">
        <h3><i class="fas fa-filter"></i> Filters</h3>
        <i class="fas fa-chevron-down arrow"></i>
    </div>

    {{-- Active filter tags --}}
    @php
        $hasFilters = request()->hasAny(['status','admin_id','role_id','ip_address','date_from','date_to','device_type','search']);
    @endphp
    @if($hasFilters)
    <div class="active-filters">
        @if(request('status'))
            <span class="filter-tag">Status: {{ ucfirst(str_replace('_', ' ', request('status'))) }} <a href="{{ route('admin.admin-log.index', array_merge(request()->except('status'), ['page' => 1])) }}">&times;</a></span>
        @endif
        @if(request('admin_id'))
            @php $filterAdmin = $admins->firstWhere('id', request('admin_id')); @endphp
            <span class="filter-tag">User: {{ $filterAdmin?->name ?? '#'.request('admin_id') }} <a href="{{ route('admin.admin-log.index', array_merge(request()->except('admin_id'), ['page' => 1])) }}">&times;</a></span>
        @endif
        @if(request('role_id'))
            @php $filterRole = $roles->firstWhere('id', request('role_id')); @endphp
            <span class="filter-tag">Role: {{ $filterRole?->name ?? '#'.request('role_id') }} <a href="{{ route('admin.admin-log.index', array_merge(request()->except('role_id'), ['page' => 1])) }}">&times;</a></span>
        @endif
        @if(request('ip_address'))
            <span class="filter-tag">IP: {{ request('ip_address') }} <a href="{{ route('admin.admin-log.index', array_merge(request()->except('ip_address'), ['page' => 1])) }}">&times;</a></span>
        @endif
        @if(request('date_from'))
            <span class="filter-tag">From: {{ request('date_from') }} <a href="{{ route('admin.admin-log.index', array_merge(request()->except('date_from'), ['page' => 1])) }}">&times;</a></span>
        @endif
        @if(request('date_to'))
            <span class="filter-tag">To: {{ request('date_to') }} <a href="{{ route('admin.admin-log.index', array_merge(request()->except('date_to'), ['page' => 1])) }}">&times;</a></span>
        @endif
        @if(request('device_type'))
            <span class="filter-tag">Device: {{ ucfirst(request('device_type')) }} <a href="{{ route('admin.admin-log.index', array_merge(request()->except('device_type'), ['page' => 1])) }}">&times;</a></span>
        @endif
        @if(request('search'))
            <span class="filter-tag">Search: "{{ request('search') }}" <a href="{{ route('admin.admin-log.index', array_merge(request()->except('search'), ['page' => 1])) }}">&times;</a></span>
        @endif
        <a href="{{ route('admin.admin-log.index') }}" class="filter-tag" style="background:#fef2f2;color:#dc2626;">Clear All &times;</a>
    </div>
    @endif

    <div class="filter-body {{ $hasFilters ? 'show' : '' }}">
        <form method="GET" action="{{ route('admin.admin-log.index') }}">
            <div class="filter-grid">
                <div class="filter-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" value="{{ request('date_from') }}">
                </div>
                <div class="filter-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" value="{{ request('date_to') }}">
                </div>
                <div class="filter-group">
                    <label>Admin User</label>
                    <select name="admin_id">
                        <option value="">All Users</option>
                        @foreach($admins as $a)
                            <option value="{{ $a->id }}" {{ request('admin_id') == $a->id ? 'selected' : '' }}>{{ $a->name }} ({{ $a->username }})</option>
                        @endforeach
                    </select>
                </div>
                <div class="filter-group">
                    <label>Role</label>
                    <select name="role_id">
                        <option value="">All Roles</option>
                        @foreach($roles as $r)
                            <option value="{{ $r->id }}" {{ request('role_id') == $r->id ? 'selected' : '' }}>{{ $r->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="filter-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="">All Statuses</option>
                        <option value="success" {{ request('status') == 'success' ? 'selected' : '' }}>Success</option>
                        <option value="active" {{ request('status') == 'active' ? 'selected' : '' }}>Active Now</option>
                        <option value="expired" {{ request('status') == 'expired' ? 'selected' : '' }}>Expired</option>
                        <option value="failed" {{ request('status') == 'failed' ? 'selected' : '' }}>All Failed</option>
                        <option value="failed_password" {{ request('status') == 'failed_password' ? 'selected' : '' }}>Wrong Password</option>
                        <option value="failed_not_found" {{ request('status') == 'failed_not_found' ? 'selected' : '' }}>User Not Found</option>
                        <option value="failed_inactive" {{ request('status') == 'failed_inactive' ? 'selected' : '' }}>Inactive Account</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Device Type</label>
                    <select name="device_type">
                        <option value="">All Devices</option>
                        <option value="desktop" {{ request('device_type') == 'desktop' ? 'selected' : '' }}>Desktop</option>
                        <option value="mobile" {{ request('device_type') == 'mobile' ? 'selected' : '' }}>Mobile</option>
                        <option value="tablet" {{ request('device_type') == 'tablet' ? 'selected' : '' }}>Tablet</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>IP Address</label>
                    <input type="text" name="ip_address" value="{{ request('ip_address') }}" placeholder="e.g. 192.168.1">
                </div>
                <div class="filter-group">
                    <label>Search</label>
                    <input type="text" name="search" value="{{ request('search') }}" placeholder="Name, username, IP, country...">
                </div>
            </div>
            <div class="filter-actions">
                <a href="{{ route('admin.admin-log.index') }}" class="btn btn-outline btn-sm">Reset</a>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i> Apply Filters</button>
            </div>
        </form>
    </div>
</div>

{{-- Data Table --}}
<div class="card">
    <div class="card-head">
        <span class="card-title"><i class="fas fa-table"></i> Login Sessions</span>
        <span class="text-muted text-sm">{{ $logs->total() }} records</span>
    </div>

    @if($logs->isEmpty())
        <div class="empty-state">
            <i class="fas fa-user-shield"></i>
            <p>No login activity found matching your filters.</p>
        </div>
    @else
    <div style="overflow-x:auto;">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width:30px;"></th>
                    <th>User</th>
                    <th>Status</th>
                    <th>IP Address</th>
                    <th>Location</th>
                    <th>Browser / Device</th>
                    <th>Login Time</th>
                    <th>Duration</th>
                    <th style="width:60px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($logs as $log)
                <tr class="main-row" onclick="toggleDetail({{ $log->id }}, this)" style="cursor:pointer;">
                    <td><i class="fas fa-chevron-down expand-icon"></i></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <div style="width:32px;height:32px;background:{{ $log->isFailed() ? '#fef2f2' : '#f0fdf4' }};border-radius:7px;display:flex;align-items:center;justify-content:center;color:{{ $log->isFailed() ? '#dc2626' : '#16a34a' }};font-weight:600;font-size:12px;">
                                {{ $log->admin_name ? strtoupper(substr($log->admin_name, 0, 1)) : '?' }}
                            </div>
                            <div>
                                <div style="font-weight:600;color:#1e293b;font-size:13px;">{{ $log->admin_name ?? '—' }}</div>
                                <div style="font-size:11px;color:#94a3b8;">{{ $log->admin_username ?? 'unknown' }}
                                    @if($log->role_name)
                                        · <span class="badge {{ $log->role_name === 'Administrator' ? 'purple' : ($log->role_name === 'Supervisor' ? 'amber' : 'gray') }}" style="padding:1px 6px;font-size:10px;">{{ $log->role_name }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        @switch($log->status)
                            @case('active')
                                <span class="badge blue"><span class="status-dot blue"></span> Active</span>
                                @break
                            @case('success')
                                <span class="badge green"><span class="status-dot green"></span> Success</span>
                                @break
                            @case('expired')
                                <span class="badge gray"><span class="status-dot gray"></span> Expired</span>
                                @break
                            @case('failed_password')
                                <span class="badge red"><span class="status-dot red"></span> Wrong Pass</span>
                                @break
                            @case('failed_not_found')
                                <span class="badge red"><span class="status-dot red"></span> Not Found</span>
                                @break
                            @case('failed_inactive')
                                <span class="badge amber"><span class="status-dot amber"></span> Inactive</span>
                                @break
                            @default
                                <span class="badge gray">{{ $log->status }}</span>
                        @endswitch
                    </td>
                    <td>
                        <span style="font-family:monospace;font-size:12px;color:#374151;">{{ $log->ip_address }}</span>
                    </td>
                    <td>
                        @if($log->ip_country)
                            <span class="nowrap" style="font-size:12px;">{{ $log->ip_city ?? '' }}{{ $log->ip_city && $log->ip_country ? ', ' : '' }}{{ $log->ip_country }}</span>
                        @else
                            <span class="text-muted text-sm">—</span>
                        @endif
                    </td>
                    <td>
                        <div style="display:flex;align-items:center;gap:6px;">
                            <i class="fas fa-{{ $log->device_type === 'mobile' ? 'mobile-alt' : ($log->device_type === 'tablet' ? 'tablet-alt' : 'desktop') }} device-icon"></i>
                            <span style="font-size:12px;">{{ $log->browser ?? '—' }}</span>
                        </div>
                    </td>
                    <td class="nowrap">
                        <div style="font-size:13px;color:#1e293b;">{{ $log->login_at?->format('d M Y') }}</div>
                        <div style="font-size:11px;color:#94a3b8;">{{ $log->login_at?->format('H:i:s') }}</div>
                    </td>
                    <td class="nowrap">
                        @if($log->status === 'active')
                            <span class="badge blue" style="font-size:10px;padding:2px 8px;">
                                <i class="fas fa-circle" style="font-size:6px;animation:pulse 2s infinite;"></i> Online
                            </span>
                        @elseif($log->formatted_duration)
                            <span style="font-size:12px;color:#475569;">{{ $log->formatted_duration }}</span>
                        @elseif($log->isFailed())
                            <span class="text-muted text-sm">—</span>
                        @else
                            <span class="text-muted text-sm">—</span>
                        @endif
                    </td>
                    <td onclick="event.stopPropagation();">
                        <div style="display:flex;gap:4px;">
                            @if($log->status === 'active')
                                <form action="{{ route('admin.admin-log.kick', $log->id) }}" method="POST" onsubmit="return confirm('Terminate this session for {{ $log->admin_name }}?');">
                                    @csrf
                                    <button type="submit" class="btn-icon-sm" style="background:#fef2f2;color:#dc2626;" title="Kick Session">
                                        <i class="fas fa-power-off"></i>
                                    </button>
                                </form>
                            @endif
                        </div>
                    </td>
                </tr>
                {{-- Expandable detail row --}}
                <tr class="detail-row" id="detail-{{ $log->id }}">
                    <td colspan="9">
                        <div class="detail-content">
                            <div class="detail-grid">
                                <div class="detail-item">
                                    <label>Session ID</label>
                                    <span style="font-family:monospace;font-size:11px;">{{ $log->session_id }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>IP Address</label>
                                    <span>{{ $log->ip_address }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>ISP</label>
                                    <span>{{ $log->ip_isp ?? '—' }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>Location</label>
                                    <span>{{ $log->ip_city ?? '—' }}, {{ $log->ip_country ?? '—' }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>Platform</label>
                                    <span>{{ $log->platform ?? '—' }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>Browser</label>
                                    <span>{{ $log->browser ?? '—' }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>Device Type</label>
                                    <span>{{ ucfirst($log->device_type) }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>Login At</label>
                                    <span>{{ $log->login_at?->format('d M Y, H:i:s') }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>Logout At</label>
                                    <span>{{ $log->logout_at?->format('d M Y, H:i:s') ?? ($log->status === 'active' ? '— (still active)' : '—') }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>Duration</label>
                                    <span>{{ $log->formatted_duration ?? ($log->status === 'active' ? 'Ongoing' : '—') }}</span>
                                </div>
                                <div class="detail-item">
                                    <label>Logout Type</label>
                                    <span>{{ $log->logout_type ? ucfirst($log->logout_type) : '—' }}</span>
                                </div>
                                @if($log->fail_reason)
                                <div class="detail-item">
                                    <label>Fail Reason</label>
                                    <span style="color:#dc2626;">{{ $log->fail_reason }}</span>
                                </div>
                                @endif
                            </div>
                            @if($log->user_agent)
                            <div class="detail-ua">{{ $log->user_agent }}</div>
                            @endif
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    {{-- Pagination --}}
    @if($logs->hasPages())
    <div class="pagination-wrap">
        <div class="pagination-info">
            Showing {{ $logs->firstItem() }}–{{ $logs->lastItem() }} of {{ $logs->total() }}
        </div>
        <div class="pagination-links">
            {{ $logs->links('pagination::simple-bootstrap-4') }}
        </div>
    </div>
    @endif
    @endif
</div>

{{-- Purge Modal --}}
<div class="modal-overlay" id="purgeModal">
    <div class="modal">
        <div class="modal-header">
            <h3><i class="fas fa-trash-alt" style="color:#dc2626;"></i> Purge Old Logs</h3>
            <button class="modal-close" onclick="closePurgeModal()">&times;</button>
        </div>
        <form action="{{ route('admin.admin-log.purge') }}" method="POST" onsubmit="return confirm('Are you sure? This action cannot be undone.');">
            @csrf
            <div class="modal-body">
                <p style="font-size:13px;color:#64748b;margin-bottom:16px;">
                    Delete login log entries older than a specified number of days. Active sessions will not be affected.
                </p>
                <div class="form-group">
                    <label>Delete entries older than</label>
                    <select name="days" class="form-control">
                        <option value="30">30 days</option>
                        <option value="60">60 days</option>
                        <option value="90" selected>90 days</option>
                        <option value="180">180 days</option>
                        <option value="365">365 days</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closePurgeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-trash-alt"></i> Purge Logs</button>
            </div>
        </form>
    </div>
</div>

@endsection

@push('scripts')
<script>
// ── Filter toggle ──
function toggleFilter() {
    const toggle = document.querySelector('.filter-toggle');
    const body = document.querySelector('.filter-body');
    toggle.classList.toggle('open');
    body.classList.toggle('show');
}

// ── Detail row expand ──
function toggleDetail(id, rowEl) {
    const detailRow = document.getElementById('detail-' + id);
    const isVisible = detailRow.classList.contains('show');

    if (isVisible) {
        detailRow.classList.remove('show');
        rowEl.classList.remove('expanded-parent');
    } else {
        detailRow.classList.add('show');
        rowEl.classList.add('expanded-parent');
    }
}

// ── Purge modal ──
function openPurgeModal() {
    document.getElementById('purgeModal').classList.add('show');
}
function closePurgeModal() {
    document.getElementById('purgeModal').classList.remove('show');
}
document.getElementById('purgeModal').addEventListener('click', function(e) {
    if (e.target === this) closePurgeModal();
});

// ── Pulse animation for active dots ──
const style = document.createElement('style');
style.textContent = '@keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:.3; } }';
document.head.appendChild(style);
</script>
@endpush
