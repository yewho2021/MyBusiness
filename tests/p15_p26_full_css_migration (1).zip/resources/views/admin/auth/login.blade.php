@php
    $__cfg = \App\Models\Configuration::getAll();
    $__fontUrl = \App\Models\Configuration::googleFontUrl();
    $__portalName = $__cfg['portal_name'] ?? 'Admin Portal';
    $__tagline = $__cfg['portal_tagline'] ?? 'Sign in to your account';
    $__logoType = $__cfg['logo_type'] ?? 'icon';
    $__logoIcon = $__cfg['logo_icon'] ?? 'fas fa-shield-alt';
    $__logoImage = $__cfg['logo_image'] ?? null;
    $__primary = $__cfg['primary'] ?? '#dc2626';
    $__loginBgType = $__cfg['login_bg_type'] ?? 'solid';
    $__loginBgColor = $__cfg['login_bg_color'] ?? '#dc2626';
    $__loginBgGradEnd = $__cfg['login_bg_gradient_end'] ?? '#991b1b';
    $__loginBgImage = $__cfg['login_bg_image'] ?? null;
    $__loginHeaderBg = $__cfg['login_header_bg'] ?? '#1e293b';
    $__loginHeaderEnd = $__cfg['login_header_bg_end'] ?? '#334155';
    $__loginCardRadius = $__cfg['login_card_radius'] ?? '16';
    $__fontFamily = $__cfg['font_family'] ?? 'Inter';
    $__footerText = $__cfg['footer_text'] ?? '© {year} {portal_name}. All rights reserved.';
    $__footerText = str_replace(['{year}', '{portal_name}'], [date('Y'), $__portalName], $__footerText);

    if ($__loginBgType === 'gradient') {
        $__bodyBg = "linear-gradient(135deg, {$__loginBgColor} 0%, {$__loginBgGradEnd} 100%)";
    } elseif ($__loginBgType === 'image' && $__loginBgImage) {
        $__bodyBg = "{$__loginBgColor}";
    } else {
        $__bodyBg = $__loginBgColor;
    }
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - {{ $__portalName }}</title>
    @if(!empty($__cfg['favicon']))
    <link rel="icon" href="{{ asset($__cfg['favicon']) }}">
    @endif
    <link href="{{ $__fontUrl }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: '{{ $__fontFamily }}', sans-serif;
            background: {{ $__bodyBg }};
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            @if($__loginBgType === 'image' && $__loginBgImage)
            background-image: url('{{ asset($__loginBgImage) }}');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            @endif
        }
        .login-container { width: 100%; max-width: 400px; }
        .login-card {
            background: #ffffff;
            border-radius: {{ $__loginCardRadius }}px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }
        .login-header {
            background: linear-gradient(135deg, {{ $__loginHeaderBg }} 0%, {{ $__loginHeaderEnd }} 100%);
            padding: 36px 30px;
            text-align: center;
        }
        .login-logo {
            width: 64px;
            height: 64px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
        }
        .login-logo i { font-size: 28px; color: #ffffff; }
        .login-header h1 { color: #ffffff; font-size: 22px; font-weight: 600; margin-bottom: 4px; }
        .login-header p { color: rgba(255, 255, 255, 0.7); font-size: 14px; }
        .login-body { padding: 32px; }
        .alert {
            padding: 12px 14px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 13px;
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
        }
        .form-group { margin-bottom: 20px; }
        .form-group label {
            display: block;
            font-size: 13px;
            font-weight: 500;
            color: var(--text-body);
            margin-bottom: 6px;
        }
        .input-group { position: relative; }
        .input-group i.input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-faint);
            font-size: 15px;
        }
        .input-group input {
            width: 100%;
            padding: 12px 14px 12px 44px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            font-family: 'Inter', sans-serif;
            background: #f9fafb;
        }
        .input-group input:focus {
            outline: none;
            border-color: {{ $__primary }};
            background: #ffffff;
        }
        .password-toggle {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-faint);
            cursor: pointer;
        }
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }
        .remember-me { display: flex; align-items: center; gap: 8px; cursor: pointer; }
        .remember-me input { width: 16px; height: 16px; }
        .remember-me span { font-size: 13px; color: var(--text-muted); }
        .btn-login {
            width: 100%;
            padding: 12px;
            background: {{ $__primary }};
            border: none;
            border-radius: 8px;
            color: #ffffff;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .btn-login:hover { opacity: 0.9; }
        .login-footer {
            text-align: center;
            padding: 20px 30px;
            border-top: 1px solid var(--hover-bg);
        }
        .login-footer p { font-size: 12px; color: var(--text-faint); }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">
                    @if(($__logoType === 'image' || $__logoType === 'both') && $__logoImage)
                        <img src="{{ asset($__logoImage) }}" alt="{{ $__portalName }}" style="max-height:40px;max-width:140px;object-fit:contain;">
                    @else
                        <i class="{{ $__logoIcon }}"></i>
                    @endif
                </div>
                <h1>{{ $__portalName }}</h1>
                <p>{{ $__tagline }}</p>
            </div>
            <div class="login-body">
                @if ($errors->any())
                    <div class="alert">
                        @foreach ($errors->all() as $error)
                            {{ $error }}
                        @endforeach
                    </div>
                @endif

                <form method="POST" action="{{ route('admin.login.submit') }}">
                    @csrf
                    <div class="form-group">
                        <label for="username">Username or Email</label>
                        <div class="input-group">
                            <i class="fas fa-user input-icon"></i>
                            <input type="text" id="username" name="username" value="{{ old('username') }}" placeholder="Enter username or email" required autofocus>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-group">
                            <i class="fas fa-lock input-icon"></i>
                            <input type="password" id="password" name="password" placeholder="Enter password" required>
                            <button type="button" class="password-toggle" onclick="togglePassword()">
                                <i class="fas fa-eye" id="toggleIcon"></i>
                            </button>
                        </div>
                    </div>
                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="remember">
                            <span>Remember me</span>
                        </label>
                    </div>
                    <button type="submit" class="btn-login">
                        <i class="fas fa-sign-in-alt"></i>
                        Sign In
                    </button>
                </form>
            </div>
            <div class="login-footer">
                <p>{!! $__footerText !!}</p>
            </div>
        </div>
    </div>
    <script>
        function togglePassword() {
            const input = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }
    </script>
</body>
</html>
