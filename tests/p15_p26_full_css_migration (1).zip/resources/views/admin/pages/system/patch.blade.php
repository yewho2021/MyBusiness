@extends('admin.layouts.app')
@section('title', 'System Patch')

@push('styles')
<style>
.page-header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px; flex-wrap:wrap; gap:12px; }
.page-header h2 { font-size:22px; font-weight:700; color:var(--text-heading); margin:0 0 4px; }
.page-desc { font-size:13px; color:var(--text-muted); margin:0; }

.sp-card { background:#fff; border:1px solid var(--border-color); border-radius:12px; padding:24px; margin-bottom:16px; }
.sp-card-title { font-size:15px; font-weight:700; color:var(--text-heading); margin-bottom:16px; display:flex; align-items:center; gap:8px; }
.sp-card-title i { color:var(--c-secondary); font-size:14px; }

/* Upload zone */
.sp-drop { border:2px dashed var(--input-border); border-radius:12px; padding:48px 24px; text-align:center; cursor:pointer; transition:all .2s; }
.sp-drop:hover { border-color:var(--c-secondary); background:var(--c-secondary-light); }
.sp-drop.dragover { border-color:var(--c-success); background:var(--c-success-light); border-style:solid; }
.sp-drop.has-file { border-color:var(--c-success); background:var(--c-success-light); border-style:solid; }
.sp-drop-icon { font-size:42px; color:var(--text-faint); margin-bottom:12px; }
.sp-drop:hover .sp-drop-icon { color:var(--c-secondary); }
.sp-drop-text { font-size:15px; color:var(--text-secondary); font-weight:500; margin-bottom:4px; }
.sp-drop-sub { font-size:12px; color:var(--text-faint); }

/* File info */
.sp-file-card { display:flex; align-items:center; gap:14px; padding:14px 18px; background:var(--table-header-bg); border:1px solid var(--border-color); border-radius:10px; margin-top:16px; }
.sp-file-icon { width:44px; height:44px; background:linear-gradient(135deg,var(--c-secondary-light),var(--c-secondary-light)); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:20px; color:var(--c-secondary); flex-shrink:0; }
.sp-file-details { flex:1; min-width:0; }
.sp-file-name { font-size:14px; font-weight:600; color:var(--text-heading); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.sp-file-meta { font-size:12px; color:var(--text-faint); margin-top:2px; }
.sp-file-remove { background:none; border:none; color:var(--text-faint); cursor:pointer; padding:4px 8px; border-radius:6px; font-size:14px; }
.sp-file-remove:hover { color:var(--c-danger); background:var(--c-danger-light); }

/* Buttons */
.sp-btn { padding:12px 24px; border-radius:10px; font-size:14px; font-weight:600; cursor:pointer; display:inline-flex; align-items:center; gap:8px; border:none; transition:all .2s; }
.sp-btn:disabled { opacity:.45; cursor:not-allowed; }
.sp-btn-preview { background:var(--c-secondary); color:#fff; }
.sp-btn-preview:hover:not(:disabled) { background:var(--c-secondary); }
.sp-btn-apply { background:linear-gradient(135deg,var(--c-danger),var(--c-primary-hover)); color:#fff; }
.sp-btn-apply:hover:not(:disabled) { box-shadow:0 4px 12px rgba(220,38,38,.3); }
.sp-btn-group { display:flex; gap:10px; margin-top:16px; }

/* Preview table */
.sp-preview { margin-top:20px; }
.sp-section { font-size:13px; font-weight:700; color:var(--text-heading); margin:16px 0 8px; display:flex; align-items:center; gap:8px; }
.sp-section i { font-size:12px; }
.sp-table { width:100%; border-collapse:collapse; font-size:13px; }
.sp-table th { text-align:left; padding:8px 12px; background:var(--table-header-bg); border-bottom:2px solid var(--border-color); color:var(--text-muted); font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:.5px; }
.sp-table td { padding:8px 12px; border-bottom:1px solid var(--border-light); color:var(--text-body); }
.sp-table tr:hover td { background:var(--table-header-bg); }
.sp-path { font-family:'JetBrains Mono',monospace; font-size:12px; }
.sp-badge { display:inline-block; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:600; }
.sp-badge-overwrite { background:var(--c-warning-light); color:var(--c-warning); }
.sp-badge-create { background:var(--c-success-light); color:var(--c-success); }
.sp-badge-newdir { background:var(--c-secondary-light); color:var(--c-secondary); }
.sp-badge-sql { background:var(--c-purple-light); color:var(--c-purple); }
.sp-badge-skip { background:var(--c-danger-light); color:var(--c-danger); }

/* Result log */
.sp-result-header { padding:16px 20px; border-radius:10px; margin-bottom:12px; display:flex; align-items:center; gap:12px; font-size:14px; font-weight:600; }
.sp-result-header.ok { background:var(--c-success-light); border:1px solid var(--c-success-border); color:var(--c-success); }
.sp-result-header.err { background:var(--c-danger-light); border:1px solid var(--c-danger-border); color:var(--c-primary-hover); }
.sp-result-header.running { background:var(--c-secondary-light); border:1px solid var(--c-secondary-border); color:var(--c-secondary); }

.sp-stats { display:flex; gap:12px; flex-wrap:wrap; margin-bottom:12px; }
.sp-stat { background:#fff; border:1px solid var(--border-color); border-radius:8px; padding:10px 16px; font-size:13px; color:var(--text-muted); display:flex; align-items:center; gap:8px; }
.sp-stat strong { font-size:16px; color:var(--text-heading); }
.sp-stat.ok strong { color:var(--c-success); }
.sp-stat.err strong { color:var(--c-danger); }

.sp-log-wrap { background:#fff; border:1px solid var(--border-color); border-radius:10px; overflow:hidden; }
.sp-log-header { padding:12px 18px; background:var(--table-header-bg); border-bottom:1px solid var(--border-color); font-size:13px; font-weight:600; color:var(--text-heading); display:flex; justify-content:space-between; align-items:center; }
.sp-log-filter { display:flex; gap:4px; }
.sp-log-filter button { padding:4px 12px; border-radius:6px; border:1px solid var(--border-color); background:#fff; font-size:12px; color:var(--text-muted); cursor:pointer; }
.sp-log-filter button:hover { background:var(--border-light); }
.sp-log-filter button.active { background:var(--text-heading); color:#fff; border-color:var(--text-heading); }

.sp-log { max-height:500px; overflow-y:auto; }
.sp-log-row { display:flex; align-items:flex-start; gap:10px; padding:8px 18px; border-bottom:1px solid var(--table-header-bg); font-size:13px; line-height:1.5; }
.sp-log-row:last-child { border-bottom:none; }
.sp-log-row i { margin-top:3px; font-size:11px; flex-shrink:0; }
.sp-log-msg { flex:1; color:var(--text-body); word-break:break-word; }
.sp-log-err { display:block; color:var(--c-primary-hover); font-size:12px; margin-top:4px; padding:6px 10px; background:var(--c-danger-light); border-radius:6px; border:1px solid var(--c-danger-border); font-family:monospace; word-break:break-all; }
.sp-log-row.type-ok i { color:var(--c-success); }
.sp-log-row.type-err i { color:var(--c-danger); }
.sp-log-row.type-info i { color:var(--c-secondary); }
.sp-log-row.type-warn i { color:var(--c-warning); }

.sp-warn { display:flex; align-items:flex-start; gap:10px; background:var(--c-warning-light); border:1px solid var(--c-warning-border); border-radius:10px; padding:14px 16px; font-size:13px; color:var(--c-warning); margin-bottom:20px; line-height:1.5; }
.sp-warn i { color:var(--c-warning); margin-top:2px; flex-shrink:0; }

/* Guide */
.sp-guide-header { cursor:pointer; }
.sp-chevron { font-size:12px; color:var(--text-faint); transition:transform .2s; margin-left:auto; }
.sp-chevron.open { transform:rotate(180deg); }
.sp-guide-body { display:none; margin-top:16px; }
.sp-guide-body.open { display:block; }
.sp-guide-actions { display:flex; gap:8px; margin-bottom:12px; }
.sp-guide-pre {
    background:var(--code-bg); color:var(--border-color); padding:20px; border-radius:10px;
    font-family:'JetBrains Mono','Fira Code',monospace; font-size:12px; line-height:1.7;
    white-space:pre; overflow-x:auto; max-height:600px; overflow-y:auto;
    border:1px solid var(--text-heading);
}
.sp-guide-pre::selection { background:var(--text-body); }
@keyframes toastIn { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }

/* Modal */
.sp-modal-overlay { position:fixed; inset:0; background:rgba(15,23,42,.5); backdrop-filter:blur(4px); z-index:9990; display:none; align-items:center; justify-content:center; }
.sp-modal-overlay.open { display:flex; }
.sp-modal { background:#fff; border-radius:16px; width:480px; max-width:92vw; box-shadow:0 25px 50px rgba(0,0,0,.2); overflow:hidden; animation:spModalIn .2s ease; }
@keyframes spModalIn { from{opacity:0;transform:scale(.95) translateY(10px)} to{opacity:1;transform:scale(1) translateY(0)} }
.sp-modal-header { padding:20px 24px 0; display:flex; align-items:center; gap:12px; }
.sp-modal-icon { width:48px; height:48px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0; }
.sp-modal-icon.warn { background:var(--c-warning-light); color:var(--c-warning); }
.sp-modal-title { font-size:17px; font-weight:700; color:var(--text-heading); }
.sp-modal-body { padding:16px 24px 20px; font-size:14px; color:var(--text-secondary); line-height:1.6; }
.sp-modal-body code { background:var(--border-light); padding:2px 6px; border-radius:4px; font-size:12px; color:var(--text-heading); }
.sp-modal-footer { padding:16px 24px; background:var(--table-header-bg); border-top:1px solid var(--border-color); display:flex; justify-content:flex-end; gap:10px; }
.sp-modal-btn { padding:10px 20px; border-radius:8px; font-size:14px; font-weight:600; cursor:pointer; border:none; transition:all .15s; }
.sp-modal-btn-cancel { background:#fff; color:var(--text-muted); border:1px solid var(--input-border); }
.sp-modal-btn-cancel:hover { background:var(--border-light); }
.sp-modal-btn-danger { background:linear-gradient(135deg,var(--c-danger),var(--c-primary-hover)); color:#fff; }
.sp-modal-btn-danger:hover { box-shadow:0 4px 12px rgba(220,38,38,.3); }
</style>
@endpush

@section('content')
<div class="page-header">
    <div>
        <h2><i class="fas fa-wrench" style="color:var(--c-secondary);margin-right:6px"></i> System Patch</h2>
        <p class="page-desc">Upload a patch .zip to apply code changes and SQL patches to the system</p>
    </div>
</div>

<div class="sp-warn">
    <i class="fas fa-exclamation-triangle"></i>
    <div><strong>Warning:</strong> Applying a patch will overwrite existing files and execute SQL statements. A backup of overwritten files is saved to <code>storage/app/patch_backups/</code>. Make sure you trust the patch source.</div>
</div>

<div class="sp-card">
    <div class="sp-card-title"><i class="fas fa-upload"></i> Upload Patch</div>

    <div class="sp-drop" id="spDropZone">
        <div class="sp-drop-icon"><i class="fas fa-file-archive"></i></div>
        <div class="sp-drop-text">Drag & drop a patch .zip here, or click to browse</div>
        <div class="sp-drop-sub">Only .zip files · Max 100 MB</div>
        <input type="file" id="spFileInput" accept=".zip" style="display:none">
    </div>

    <div id="spFileInfo" style="display:none;">
        <div class="sp-file-card">
            <div class="sp-file-icon"><i class="fas fa-file-archive"></i></div>
            <div class="sp-file-details">
                <div class="sp-file-name" id="spFileName"></div>
                <div class="sp-file-meta" id="spFileMeta"></div>
            </div>
            <button type="button" class="sp-file-remove" onclick="spClearFile()"><i class="fas fa-times"></i></button>
        </div>
    </div>

    <div class="sp-btn-group">
        <button class="sp-btn sp-btn-preview" id="spPreviewBtn" disabled onclick="spPreview()">
            <i class="fas fa-search"></i> Preview Changes
        </button>
        <button class="sp-btn sp-btn-apply" id="spApplyBtn" style="display:none;" onclick="spApply()">
            <i class="fas fa-bolt"></i> Apply Patch
        </button>
    </div>
</div>

{{-- Preview section --}}
<div id="spPreviewSection" style="display:none;">
    <div class="sp-card">
        <div class="sp-card-title"><i class="fas fa-list-check"></i> Patch Preview</div>
        <div id="spPreviewContent"></div>
    </div>
</div>

{{-- Results section --}}
<div id="spResultSection" style="display:none;"></div>

{{-- Patch Format Guide --}}
<div class="sp-card" style="margin-top:8px;">
    <div class="sp-guide-header" onclick="document.getElementById('spGuideBody').classList.toggle('open');this.querySelector('.sp-chevron').classList.toggle('open')">
        <div class="sp-card-title" style="margin-bottom:0;cursor:pointer;user-select:none;">
            <i class="fas fa-book"></i> Patch Format Guide
            <i class="fas fa-chevron-down sp-chevron"></i>
        </div>
        <span style="font-size:12px;color:var(--text-faint);">Click to expand — copy & paste to Claude for building patches</span>
    </div>
    <div class="sp-guide-body" id="spGuideBody">
        <div class="sp-guide-actions">
            <button class="btn btn-outline btn-sm" onclick="event.stopPropagation();spCopyGuide()"><i class="fas fa-copy"></i> Copy Guide</button>
            <button class="btn btn-outline btn-sm" onclick="event.stopPropagation();spDownloadGuide()"><i class="fas fa-download"></i> Download .md</button>
        </div>
        <pre class="sp-guide-pre" id="spGuideText"># {{ \App\Models\Configuration::get('portal_name', config('app.name', 'Admin Portal')) }} Patch Format Guide

## Zip Structure

```
patch-name.zip
├── app/
│   └── Http/Controllers/Admin/SomeController.php
├── resources/
│   └── views/admin/pages/module/page.blade.php
├── routes/
│   └── admin.php
├── database/
│   └── patches/
│       └── 2026_MM_DD_patch_name.sql
└── bootstrap/
    └── app.php
```

**Rule:** Zip file paths = target paths relative to project root.

---

## Code Files

- File exists → **Overwrite** (backup saved to storage/app/patch_backups/)
- File doesn't exist → **Create** (parent dirs auto-created)
- Blade cache auto-cleared after apply

### Blocked paths (auto-skipped):
.env, .htaccess, artisan, composer.json, composer.lock, vendor/*, node_modules/*, storage/logs/*, .git/*

---

## SQL Patches

Any `.sql` file in the zip → parsed, pre-validated, then executed.

### Naming: `database/patches/YYYY_MM_DD_description.sql`

### Template:

```sql
-- =============================================
-- Module Name
-- Created: YYYY-MM-DD
-- =============================================

-- Schema changes
ALTER TABLE `tbl_example`
    ADD COLUMN `new_col` VARCHAR(255) NULL DEFAULT NULL AFTER `existing_col`;

-- Config rows
INSERT INTO `tbl_configuration`
    (`group`, `key`, `value`, `type`, `label`, `description`, `options`, `default_value`, `sort_order`, `is_active`)
VALUES
    ('group', 'key', 'default', 'text', 'Label', 'Description.', NULL, 'default', 1, 1);

-- Menu entry
INSERT INTO `tbl_admin_menus`
    (`group_id`, `parent_id`, `level`, `title`, `icon`, `route_name`, `permission_key`, `sort_order`, `is_active`, `created_at`, `updated_at`)
VALUES
    (1, NULL, 1, 'Module Name', 'fas fa-icon', 'admin.module.index', 'module_perm', 60, 1, NOW(), NOW());

-- Role access (superadmin = role_id 1)
INSERT INTO `tbl_admin_role_menu_access` (`role_id`, `menu_id`, `created_at`, `updated_at`)
SELECT 1, id, NOW(), NOW()
FROM `tbl_admin_menus`
WHERE `route_name` = 'admin.module.index'
AND id NOT IN (SELECT menu_id FROM `tbl_admin_role_menu_access` WHERE role_id = 1)
LIMIT 1;

-- Changelog
INSERT INTO `tbl_changelog`
    (`app_type`, `version`, `title`, `details`, `technical_info`, `created_at`)
VALUES (
    'office', '1.XX.0', 'Module Name',
    'Description of changes.', '{"info":"value"}', NOW()
);
```

---

## Key Table Schemas

### tbl_admin_menus
group_id, parent_id, level, title, icon, route_name, permission_key, sort_order, is_active, created_at, updated_at

### tbl_admin_role_menu_access (NO has_access column!)
role_id, menu_id, created_at, updated_at

### tbl_configuration
group, key, value, type, label, description, options, default_value, sort_order, is_active

### tbl_changelog
app_type, version, title, details, technical_info, created_at

---

## Project Conventions

- **Auth:** Use `$request->attributes->get('admin')` for current admin, `$request->attributes->get('admin_id')` for ID. Never `Auth::user()` or raw cookie.
- **Routes:** All in `routes/admin.php`, named `admin.{module}.{action}`
- **CSS:** Page-level in `@@push('styles')`, hardcoded hex colors
- **JS:** Native `fetch()` with CSRF, no jQuery/Axios
- **Views:** Extend `admin.layouts.app`, use `@@push('styles')` and `@@push('scripts')`
- **DB:** No migrations — SQL patches only. Table prefix: `tbl_`
- **Deploy:** No `composer install` on server — vendor committed
- **Encrypted fields:** Laravel `Crypt::encrypt()` / `Crypt::decrypt()`</pre>
    </div>
</div>

{{-- Confirm Modal --}}
<div class="sp-modal-overlay" id="spConfirmModal">
    <div class="sp-modal">
        <div class="sp-modal-header">
            <div class="sp-modal-icon warn"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="sp-modal-title">Apply Patch?</div>
        </div>
        <div class="sp-modal-body">
            This will <strong>overwrite existing files</strong> and <strong>execute SQL statements</strong> on your live system.
            <br><br>
            A backup of all original files will be saved to <code>storage/app/patch_backups/</code> before overwriting.
        </div>
        <div class="sp-modal-footer">
            <button class="sp-modal-btn sp-modal-btn-cancel" onclick="spCloseModal()">Cancel</button>
            <button class="sp-modal-btn sp-modal-btn-danger" id="spModalConfirmBtn" onclick="spConfirmApply()">
                <i class="fas fa-bolt"></i> Yes, Apply Patch
            </button>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
const CSRF = document.querySelector('meta[name="csrf-token"]').content;
const zone = document.getElementById('spDropZone');
const fileInput = document.getElementById('spFileInput');
const fileInfo = document.getElementById('spFileInfo');
const previewBtn = document.getElementById('spPreviewBtn');
const applyBtn = document.getElementById('spApplyBtn');

let currentFile = null;

function formatSize(b) { return b >= 1048576 ? (b/1048576).toFixed(2)+' MB' : b >= 1024 ? (b/1024).toFixed(1)+' KB' : b+' B'; }
function escHtml(s) { return s ? s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;') : ''; }

function spSelectFile(file) {
    if (!file || !file.name.endsWith('.zip')) { alert('Only .zip files are allowed.'); return; }
    currentFile = file;
    const dt = new DataTransfer(); dt.items.add(file); fileInput.files = dt.files;
    document.getElementById('spFileName').textContent = file.name;
    document.getElementById('spFileMeta').textContent = formatSize(file.size) + ' · ZIP file';
    fileInfo.style.display = 'block';
    zone.classList.add('has-file');
    previewBtn.disabled = false;
    applyBtn.style.display = 'none';
    document.getElementById('spPreviewSection').style.display = 'none';
    document.getElementById('spResultSection').style.display = 'none';
}

function spClearFile() {
    currentFile = null;
    fileInput.value = '';
    fileInfo.style.display = 'none';
    zone.classList.remove('has-file');
    previewBtn.disabled = true;
    applyBtn.style.display = 'none';
    document.getElementById('spPreviewSection').style.display = 'none';
    document.getElementById('spResultSection').style.display = 'none';
}

// Drag & drop
zone.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', () => { if (fileInput.files[0]) spSelectFile(fileInput.files[0]); });
zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('dragover'); });
zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
zone.addEventListener('drop', (e) => { e.preventDefault(); zone.classList.remove('dragover'); if (e.dataTransfer.files[0]) spSelectFile(e.dataTransfer.files[0]); });

// ── Preview ─────────────────────────────────
async function spPreview() {
    if (!currentFile) return;
    previewBtn.disabled = true;
    previewBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Scanning...';

    const formData = new FormData();
    formData.append('patch_file', currentFile);

    try {
        const res = await fetch("{{ route('admin.system-patch.preview') }}", {
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': CSRF, 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
            body: formData
        });
        const data = await res.json();
        if (!data.success) {
            alert(data.error || 'Preview failed');
            return;
        }
        renderPreview(data);
    } catch(err) {
        alert('Network error: ' + err.message);
    } finally {
        previewBtn.disabled = false;
        previewBtn.innerHTML = '<i class="fas fa-search"></i> Preview Changes';
    }
}

function renderPreview(data) {
    let html = '<div style="font-size:13px;color:var(--text-muted);margin-bottom:12px">' + data.total_entries + ' entries · ' + data.total_size + '</div>';

    // Code files table
    if (data.code_files.length) {
        html += '<div class="sp-section"><i class="fas fa-file-code" style="color:var(--c-secondary)"></i> Code Files (' + data.code_files.length + ')</div>';
        html += '<table class="sp-table"><thead><tr><th>File Path</th><th>Size</th><th>Action</th></tr></thead><tbody>';
        data.code_files.forEach(f => {
            const badge = f.action === 'overwrite'
                ? '<span class="sp-badge sp-badge-overwrite">Overwrite</span>'
                : f.action.includes('new dir')
                    ? '<span class="sp-badge sp-badge-newdir">Create (new dir)</span>'
                    : '<span class="sp-badge sp-badge-create">Create</span>';
            html += '<tr><td class="sp-path">' + escHtml(f.path) + '</td><td>' + formatSize(f.size) + '</td><td>' + badge + '</td></tr>';
        });
        html += '</tbody></table>';
    }

    // SQL files
    if (data.sql_files.length) {
        html += '<div class="sp-section"><i class="fas fa-database" style="color:var(--c-purple)"></i> SQL Patches (' + data.sql_files.length + ')</div>';

        data.sql_files.forEach(sf => {
            const validIcon = sf.valid ? '<i class="fas fa-check-circle" style="color:var(--c-success)"></i>' : '<i class="fas fa-exclamation-triangle" style="color:var(--c-danger)"></i>';
            const validText = sf.valid ? '<span style="color:var(--c-success);font-weight:600">All checks passed</span>' : '<span style="color:var(--c-danger);font-weight:600">' + sf.err_count + ' error(s) found</span>';

            html += '<div style="background:var(--table-header-bg);border:1px solid var(--border-color);border-radius:10px;padding:14px 18px;margin-bottom:12px">';
            html += '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">';
            html += '<span class="sp-path" style="font-weight:600">' + validIcon + ' ' + escHtml(sf.path) + '</span>';
            html += '<span style="font-size:12px">' + sf.stmt_count + ' statement(s) · ' + validText + '</span>';
            html += '</div>';

            if (sf.statements && sf.statements.length) {
                html += '<table class="sp-table" style="font-size:12px"><thead><tr><th style="width:30px">#</th><th>Statement</th><th style="width:80px">Status</th></tr></thead><tbody>';
                sf.statements.forEach(st => {
                    const stIcon = st.status === 'ok' ? '<span class="sp-badge sp-badge-create">OK</span>'
                        : st.status === 'warn' ? '<span class="sp-badge sp-badge-overwrite">Warn</span>'
                        : '<span class="sp-badge sp-badge-skip">Error</span>';
                    html += '<tr><td>' + st.num + '</td><td class="sp-path">' + escHtml(st.preview);
                    if (st.error) html += '<div class="sp-log-err" style="margin-top:4px">' + escHtml(st.error) + '</div>';
                    html += '</td><td>' + stIcon + '</td></tr>';
                });
                html += '</tbody></table>';
            }
            html += '</div>';
        });
    }

    // Skipped
    if (data.skipped && data.skipped.length) {
        html += '<div class="sp-section"><i class="fas fa-ban" style="color:var(--c-danger)"></i> Blocked (' + data.skipped.length + ')</div>';
        html += '<table class="sp-table"><thead><tr><th>File</th><th>Reason</th></tr></thead><tbody>';
        data.skipped.forEach(f => {
            html += '<tr><td class="sp-path">' + escHtml(f.path) + '</td><td><span class="sp-badge sp-badge-skip">' + escHtml(f.reason) + '</span></td></tr>';
        });
        html += '</tbody></table>';
    }

    document.getElementById('spPreviewContent').innerHTML = html;
    document.getElementById('spPreviewSection').style.display = 'block';

    // Check if SQL has errors — block apply if so
    const hasSqlErrors = data.sql_files.some(f => !f.valid);
    if (hasSqlErrors) {
        applyBtn.style.display = 'inline-flex';
        applyBtn.disabled = true;
        applyBtn.title = 'Fix SQL errors before applying';
        applyBtn.innerHTML = '<i class="fas fa-ban"></i> SQL Errors — Fix Before Applying';
    } else {
        applyBtn.style.display = 'inline-flex';
        applyBtn.disabled = false;
        applyBtn.title = '';
        applyBtn.innerHTML = '<i class="fas fa-bolt"></i> Apply Patch';
    }
}

// ── Apply ───────────────────────────────────
async function spApply() {
    if (!currentFile) return;
    document.getElementById('spConfirmModal').classList.add('open');
}

function spCloseModal() {
    document.getElementById('spConfirmModal').classList.remove('open');
}

// Close modal on overlay click
document.getElementById('spConfirmModal').addEventListener('click', function(e) {
});

document.addEventListener('keydown', function(e) {
});

async function spConfirmApply() {
    spCloseModal();

    applyBtn.disabled = true;
    applyBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Applying...';
    previewBtn.disabled = true;

    const resultDiv = document.getElementById('spResultSection');
    resultDiv.style.display = 'block';
    resultDiv.innerHTML = '<div class="sp-result-header running"><i class="fas fa-circle-notch fa-spin"></i> Applying patch...</div>';

    const formData = new FormData();
    formData.append('patch_file', currentFile);

    try {
        const res = await fetch("{{ route('admin.system-patch.apply') }}", {
            method: 'POST',
            headers: { 'X-CSRF-TOKEN': CSRF, 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
            body: formData
        });
        const data = await res.json();
        resultDiv.innerHTML = renderResult(data);
    } catch(err) {
        resultDiv.innerHTML = '<div class="sp-result-header err"><i class="fas fa-times-circle"></i> Network error: ' + escHtml(err.message) + '</div>';
    } finally {
        applyBtn.disabled = false;
        applyBtn.innerHTML = '<i class="fas fa-bolt"></i> Apply Patch';
        previewBtn.disabled = false;
    }
}

function renderResult(data) {
    const icons = { ok:'check-circle', err:'times-circle', info:'info-circle', warn:'exclamation-triangle' };
    let html = '';

    // Header
    const cls = data.success ? 'ok' : 'err';
    const icon = data.success ? 'check-circle' : 'times-circle';
    html += '<div class="sp-result-header ' + cls + '"><i class="fas fa-' + icon + '"></i> ' + escHtml(data.summary) + '</div>';

    // Stats
    html += '<div class="sp-stats">';
    html += '<div class="sp-stat ok"><i class="fas fa-file"></i> Files: <strong>' + data.files_ok + '</strong></div>';
    if (data.files_overwritten > 0) html += '<div class="sp-stat"><i class="fas fa-edit"></i> Overwritten: <strong>' + data.files_overwritten + '</strong></div>';
    if (data.files_created > 0) html += '<div class="sp-stat"><i class="fas fa-plus"></i> Created: <strong>' + data.files_created + '</strong></div>';
    if (data.files_err > 0) html += '<div class="sp-stat err"><i class="fas fa-times"></i> File errors: <strong>' + data.files_err + '</strong></div>';
    if (data.sql_count > 0) {
        html += '<div class="sp-stat ok"><i class="fas fa-database"></i> SQL: <strong>' + data.sql_ok + '</strong></div>';
        if (data.sql_err > 0) html += '<div class="sp-stat err"><i class="fas fa-database"></i> SQL errors: <strong>' + data.sql_err + '</strong></div>';
    }
    html += '<div class="sp-stat"><i class="fas fa-clock"></i> <strong>' + data.elapsed_ms + 'ms</strong></div>';
    html += '</div>';

    // Log
    if (data.log && data.log.length) {
        const hasErr = data.log.some(l => l.type === 'err');
        html += '<div class="sp-log-wrap">';
        html += '<div class="sp-log-header"><span><i class="fas fa-list"></i> Execution Log (' + data.log.length + ' entries)</span>';
        if (hasErr) {
            html += '<div class="sp-log-filter">';
            html += '<button class="active" onclick="spFilterLog(this,\'all\')">All</button>';
            html += '<button onclick="spFilterLog(this,\'err\')">Errors</button>';
            html += '<button onclick="spFilterLog(this,\'ok\')">Success</button>';
            html += '</div>';
        }
        html += '</div><div class="sp-log">';
        data.log.forEach(e => {
            const ic = icons[e.type] || 'chevron-right';
            let msg = '<span class="sp-log-msg">' + escHtml(e.msg);
            if (e.error) msg += '<span class="sp-log-err">' + escHtml(e.error) + '</span>';
            msg += '</span>';
            html += '<div class="sp-log-row type-' + e.type + '" data-type="' + e.type + '"><i class="fas fa-' + ic + '"></i>' + msg + '</div>';
        });
        html += '</div></div>';
    }

    return html;
}

function spFilterLog(btn, type) {
    const wrap = btn.closest('.sp-log-wrap');
    wrap.querySelectorAll('.sp-log-filter button').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    wrap.querySelectorAll('.sp-log-row').forEach(row => {
        row.style.display = (type === 'all' || row.dataset.type === type) ? '' : 'none';
    });
}

function spCopyGuide() {
    const text = document.getElementById('spGuideText').textContent;
    navigator.clipboard.writeText(text).then(() => {
        spToast('Guide copied to clipboard!');
    }).catch(() => {
        // Fallback
        const ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy');
        document.body.removeChild(ta);
        spToast('Guide copied!');
    });
}

function spDownloadGuide() {
    const text = document.getElementById('spGuideText').textContent;
    const blob = new Blob([text], { type: 'text/markdown' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'PATCH_FORMAT.md';
    a.click();
    URL.revokeObjectURL(a.href);
    spToast('Downloaded PATCH_FORMAT.md');
}

function spToast(msg) {
    document.querySelectorAll('.sp-toast').forEach(t => t.remove());
    const t = document.createElement('div');
    t.className = 'sp-toast';
    t.innerHTML = '<i class="fas fa-check-circle"></i> ' + msg;
    t.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:10px 16px;border-radius:8px;background:var(--c-success);color:#fff;font-size:12px;font-weight:500;display:flex;align-items:center;gap:7px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,.15);animation:toastIn .3s ease';
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(() => t.remove(), 300); }, 2500);
}
</script>
@endpush
