@extends('admin.layouts.app')

@section('title', 'System Change Log')

@section('content')
    <div class="sc-page-header">
        <div>
            <h2 class="sc-page-title">System Change Log</h2>
            <p class="sc-page-subtitle">Tracking updates and patches across Office and Apps portals</p>
        </div>
        <div style="display:flex;gap:8px;">
            <a href="{{ route('admin.changelog.index') }}" class="sc-btn sc-btn--{{ !request('app_type') ? 'primary' : 'outline' }} sc-btn--sm">All Updates</a>
            <a href="{{ route('admin.changelog.index', ['app_type' => 'office']) }}" class="sc-btn sc-btn--{{ request('app_type') == 'office' ? 'primary' : 'outline' }} sc-btn--sm">Office Portal</a>
            <a href="{{ route('admin.changelog.index', ['app_type' => 'apps']) }}" class="sc-btn sc-btn--{{ request('app_type') == 'apps' ? 'primary' : 'outline' }} sc-btn--sm">Apps Portal</a>
        </div>
    </div>

    @if($logs->isEmpty())
        <x-card>
            <div style="padding:40px;text-align:center;color:var(--text-faint);">
                <i class="fas fa-clipboard-list" style="font-size:48px;margin-bottom:16px;display:block;"></i>
                <p>No change logs found.</p>
            </div>
        </x-card>
    @else
        <x-card :padding="false">
            <div class="sc-overflow-x">
                <table class="sc-table" id="changelogTable">
                    <thead>
                        <tr>
                            <th style="width:40px;"></th>
                            <th style="width:150px;">Version</th>
                            <th style="width:120px;">Portal</th>
                            <th>Title / Summary</th>
                            <th style="width:180px;">Date (GMT+8)</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($logs as $log)
                            <tr class="cl-main-row" onclick="toggleClRow({{ $log->id }}, this)" style="cursor:pointer;">
                                <td><i class="fas fa-chevron-down cl-expand-icon" style="color:var(--text-faint);transition:transform .2s;"></i></td>
                                <td><code style="font-weight:600;color:var(--c-secondary,var(--c-secondary));background:var(--c-secondary-light,var(--c-secondary-light));padding:2px 6px;border-radius:4px;">{{ $log->version }}</code></td>
                                <td>
                                    <x-badge :variant="$log->app_type == 'office' ? 'info' : 'warning'">
                                        {{ $log->app_type == 'office' ? 'Office' : 'Portal' }}
                                    </x-badge>
                                </td>
                                <td style="font-weight:600;color:var(--header-text,var(--text-heading));">{{ $log->title }}</td>
                                <td class="sc-text-muted">{{ $log->created_at->format('d M Y, H:i') }}</td>
                            </tr>
                            <tr id="cl-details-{{ $log->id }}" style="display:none;">
                                <td colspan="5">
                                    <div style="padding:20px 40px;border-bottom:1px solid var(--border-color,var(--border-color));font-size:var(--fs-base,14px);line-height:1.6;color:var(--text-secondary);">
                                        <h4 style="font-size:var(--fs-sm,13px);font-weight:700;color:var(--header-text,var(--text-heading));margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px;">Description & Changes</h4>
                                        <div style="white-space:pre-wrap;">{{ $log->details }}</div>

                                        @if($log->technical_info)
                                            <h4 style="margin-top:20px;font-size:var(--fs-sm,13px);font-weight:700;color:var(--header-text,var(--text-heading));text-transform:uppercase;letter-spacing:.5px;">Technical Details</h4>
                                            <div style="margin-top:8px;padding:12px;background:var(--code-bg);border-radius:6px;color:var(--border-color);font-family:var(--font-mono);font-size:var(--fs-xs,12px);">
                                                <pre style="margin:0;">{{ json_encode($log->technical_info, JSON_PRETTY_PRINT) }}</pre>
                                            </div>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </x-card>
        <div style="padding:16px 0;display:flex;justify-content:center;">
            {{ $logs->links('pagination::simple-bootstrap-4') }}
        </div>
    @endif
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
@endpush

@push('scripts')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script>
    jQuery(document).ready(function() {
        jQuery('#changelogTable').DataTable({
            paging: false,
            ordering: true,
            order: [],
            searching: true,
            info: true,
            columnDefs: [
                { orderable: false, targets: 0 },
                { type: 'string', targets: 1 },
            ],
            language: {
                search: '',
                searchPlaceholder: 'Search changelog...',
                lengthMenu: 'Show _MENU_',
                info: 'Showing _START_ to _END_ of _TOTAL_ entries',
                emptyTable: 'No changelog entries found',
            },
            dom: '<"dt-top"lf>rt<"dt-bottom"ip>',
        });
    });

    function toggleClRow(id, rowEl) {
        var detailsRow = document.getElementById('cl-details-' + id);
        var icon = rowEl.querySelector('.cl-expand-icon');
        var isVisible = detailsRow.style.display === 'table-row';

        if (isVisible) {
            detailsRow.style.display = 'none';
            if (icon) icon.style.transform = '';
            rowEl.style.background = '';
        } else {
            detailsRow.style.display = 'table-row';
            if (icon) icon.style.transform = 'rotate(180deg)';
            rowEl.style.background = 'var(--table-header-bg,var(--table-header-bg))';
        }
    }
</script>
@endpush
