@extends('admin.layouts.app')
@section('title', 'Image Tools')

@push('styles')
<style>
.page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; }
.page-header h1 { font-size: 24px; font-weight: 700; color: var(--header-text,var(--code-bg)); margin-bottom: 5px; }
.page-header p { font-size: 14px; color: var(--text-muted); }

.tabs { display: flex; gap: 4px; background: var(--border-light); border-radius: var(--card-radius,12px); padding: 4px; margin-bottom: 22px; flex-wrap: wrap; }
.tab-btn { padding: 10px 18px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; border: none; background: transparent; color: var(--text-muted); transition: all .2s; display: inline-flex; align-items: center; gap: 7px; }
.tab-btn:hover { color: var(--header-text,var(--text-heading)); background: rgba(255,255,255,.5); }
.tab-btn.active { background: var(--card-bg,#fff); color: var(--c-primary,var(--c-danger)); box-shadow: 0 1px 3px rgba(0,0,0,.1); }

.card { background: var(--card-bg,#fff); border-radius: 14px; border: 1px solid var(--border-color,var(--border-color)); box-shadow: 0 1px 3px rgba(0,0,0,.04); }
.card-body { padding: 22px; }
.tab-content { display: none; }
.tab-content.active { display: block; }

.tool-layout { display: grid; grid-template-columns: 1fr 320px; gap: 22px; }
@media(max-width:900px) { .tool-layout { grid-template-columns: 1fr; } }

.upload-area { width: 100%; min-height: 300px; border: 2px dashed var(--input-border); border-radius: var(--card-radius,12px); display: flex; flex-direction: column; align-items: center; justify-content: center; cursor: pointer; transition: all .2s; background: var(--table-header-bg,var(--table-header-bg)); position: relative; overflow: hidden; }
.upload-area:hover, .upload-area.dragover { border-color: var(--c-secondary); background: var(--c-secondary-light); }
.upload-area i.upload-icon { font-size: 40px; color: var(--text-faint); margin-bottom: 12px; }
.upload-area p { font-size: 14px; color: var(--text-muted); }
.upload-area input[type="file"] { display: none; }
.upload-area .preview-img { max-width: 100%; max-height: 300px; object-fit: contain; border-radius: 8px; }
.upload-area .preview-wrap { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; padding: 12px; }

.settings-panel { background: var(--table-header-bg,var(--table-header-bg)); border-radius: var(--card-radius,12px); border: 1px solid var(--border-color,var(--border-color)); padding: 22px; }
.settings-panel h4 { font-size: 15px; font-weight: 700; color: var(--header-text,var(--text-heading)); margin-bottom: 18px; display: flex; align-items: center; gap: 8px; }
.settings-panel h4 i { color: var(--text-muted); font-size: 14px; }

.form-group { margin-bottom: 16px; }
.form-group label { display: block; font-size: 13px; font-weight: 600; color: var(--text-body); margin-bottom: 5px; }
.form-control { width: 100%; padding: 10px 14px; border: 1.5px solid var(--border-color); border-radius: 8px; font-size: 14px; color: var(--header-text,var(--text-heading)); background: var(--card-bg,#fff); box-sizing: border-box; }
.form-control:focus { outline: none; border-color: var(--c-secondary); box-shadow: 0 0 0 3px rgba(59,130,246,.1); }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.form-hint { font-size: 11px; color: var(--text-faint); margin-top: 4px; }

.btn { padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; display: inline-flex; align-items: center; gap: 7px; transition: all .2s; width: 100%; justify-content: center; }
.btn-primary { background: linear-gradient(135deg, var(--c-danger) 0%, var(--c-primary-hover) 100%); color: #fff; }
.btn-primary:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(0,0,0,.1); }

.range-wrap { display: flex; align-items: center; gap: 12px; }
.range-wrap input[type="range"] { flex: 1; height: 6px; -webkit-appearance: none; background: var(--border-color); border-radius: 3px; outline: none; }
.range-wrap input[type="range"]::-webkit-slider-thumb { -webkit-appearance: none; width: 18px; height: 18px; border-radius: 50%; background: var(--c-primary,var(--c-danger)); cursor: pointer; }
.range-value { min-width: 45px; text-align: center; font-size: 14px; font-weight: 700; color: var(--header-text,var(--text-heading)); }

.radio-group { display: flex; flex-wrap: wrap; gap: 8px; }
.radio-option { padding: 8px 16px; border: 1.5px solid var(--border-color); border-radius: 8px; font-size: 13px; font-weight: 500; color: var(--text-secondary); cursor: pointer; transition: all .15s; }
.radio-option:hover { border-color: var(--text-faint); }
.radio-option.selected { border-color: var(--c-primary,var(--c-danger)); background: var(--c-danger-light); color: var(--c-primary,var(--c-danger)); font-weight: 600; }

.img-info { background: var(--code-bg); border-radius: var(--card-radius,10px); padding: 14px 18px; margin-top: 14px; }
.img-info-row { display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid var(--text-heading); }
.img-info-row:last-child { border-bottom: none; }
.img-info-label { font-size: 12px; color: var(--text-faint); font-weight: 600; text-transform: uppercase; }
.img-info-value { font-size: 13px; color: var(--border-color); font-weight: 500; font-family: monospace; }

.loading-overlay { display: none; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(255,255,255,.85); z-index: 10; align-items: center; justify-content: center; border-radius: var(--card-radius,12px); flex-direction: column; gap: 10px; }
.loading-overlay.show { display: flex; }
.loading-overlay i { font-size: 28px; color: var(--c-primary,var(--c-danger)); animation: spin 1s linear infinite; }
.loading-overlay p { font-size: 14px; color: var(--text-muted); }
@keyframes spin { to { transform: rotate(360deg); } }

.toast { position: fixed; bottom: 24px; right: 24px; padding: 14px 22px; border-radius: var(--card-radius,10px); font-size: 14px; font-weight: 500; z-index: 10000; box-shadow: 0 8px 24px rgba(0,0,0,.15); display: none; align-items: center; gap: 8px; }
.toast.success { background: var(--c-success); color: #fff; }
.toast.error { background: var(--c-primary-hover); color: #fff; }
.toast.show { display: flex; }
</style>
@endpush

@section('content')
<div class="page-header">
    <div>
        <h1>Image Tools</h1>
        <p>Resize, crop, convert, compress, watermark, and rotate images</p>
    </div>
</div>

<div class="tabs">
    <button class="tab-btn active" onclick="switchTab('resize',this)"><i class="fas fa-expand-arrows-alt"></i> Resize</button>
    <button class="tab-btn" onclick="switchTab('crop',this)"><i class="fas fa-crop-alt"></i> Crop</button>
    <button class="tab-btn" onclick="switchTab('convert',this)"><i class="fas fa-exchange-alt"></i> Convert</button>
    <button class="tab-btn" onclick="switchTab('compress',this)"><i class="fas fa-compress-arrows-alt"></i> Compress</button>
    <button class="tab-btn" onclick="switchTab('watermark',this)"><i class="fas fa-copyright"></i> Watermark</button>
    <button class="tab-btn" onclick="switchTab('rotate',this)"><i class="fas fa-sync-alt"></i> Rotate</button>
</div>

@foreach(['resize','crop','convert','compress','watermark','rotate'] as $idx => $tool)
<div class="tab-content {{ $idx === 0 ? 'active' : '' }}" id="tab-{{ $tool }}">
<div class="card"><div class="card-body">
    <form id="{{ $tool }}Form" enctype="multipart/form-data">
        @csrf
        <div class="tool-layout">
            <div style="position:relative;">
                <div class="upload-area" id="upload{{ ucfirst($tool) }}" onclick="document.getElementById('img{{ ucfirst($tool) }}').click()">
                    <i class="fas fa-cloud-upload-alt upload-icon"></i>
                    <p>Drop image here or click to browse</p>
                    <input type="file" id="img{{ ucfirst($tool) }}" name="image" accept="image/*">
                </div>
                <div class="loading-overlay" id="load{{ ucfirst($tool) }}"><i class="fas fa-spinner"></i><p>Processing...</p></div>
                @if($tool === 'resize')
                <div class="img-info" id="infoResize" style="display:none;"></div>
                @endif
            </div>
            <div class="settings-panel">
                @if($tool === 'resize')
                <h4><i class="fas fa-cog"></i> Resize Settings</h4>
                <div class="form-row">
                    <div class="form-group"><label>Width (px)</label><input type="number" name="width" class="form-control" placeholder="Auto" min="1" max="10000"></div>
                    <div class="form-group"><label>Height (px)</label><input type="number" name="height" class="form-control" placeholder="Auto" min="1" max="10000"></div>
                </div>
                <div class="form-group"><label>Mode</label>
                    <select name="mode" class="form-control">
                        <option value="fit">Fit (maintain ratio)</option>
                        <option value="scale">Scale (exact ratio)</option>
                        <option value="exact">Exact (stretch)</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-magic"></i> Resize & Download</button>

                @elseif($tool === 'crop')
                <h4><i class="fas fa-crop-alt"></i> Crop Settings</h4>
                <div class="form-row">
                    <div class="form-group"><label>Width (px)</label><input type="number" name="width" class="form-control" min="1" required></div>
                    <div class="form-group"><label>Height (px)</label><input type="number" name="height" class="form-control" min="1" required></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>X Offset</label><input type="number" name="x" class="form-control" value="0" min="0"></div>
                    <div class="form-group"><label>Y Offset</label><input type="number" name="y" class="form-control" value="0" min="0"></div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-crop-alt"></i> Crop & Download</button>

                @elseif($tool === 'convert')
                <h4><i class="fas fa-exchange-alt"></i> Convert Format</h4>
                <div class="form-group"><label>Target Format</label>
                    <div class="radio-group" id="formatGroup">
                        @foreach(['jpg'=>'JPEG','png'=>'PNG','webp'=>'WEBP','gif'=>'GIF','bmp'=>'BMP'] as $val => $lbl)
                        <div class="radio-option {{ $val==='jpg'?'selected':'' }}" data-value="{{ $val }}" onclick="selectRadio('formatGroup',this)">{{ $lbl }}</div>
                        @endforeach
                    </div>
                    <input type="hidden" name="format" value="jpg">
                </div>
                <div class="form-group"><label>Quality</label>
                    <div class="range-wrap"><input type="range" name="quality" min="1" max="100" value="90" oninput="this.nextElementSibling.textContent=this.value+'%'"><span class="range-value">90%</span></div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-exchange-alt"></i> Convert & Download</button>

                @elseif($tool === 'compress')
                <h4><i class="fas fa-compress-arrows-alt"></i> Compression</h4>
                <div class="form-group"><label>Quality</label>
                    <div class="range-wrap"><input type="range" name="quality" min="1" max="100" value="60" oninput="this.nextElementSibling.textContent=this.value+'%'"><span class="range-value">60%</span></div>
                    <p class="form-hint">Lower = smaller file, more compression</p>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-compress-arrows-alt"></i> Compress & Download</button>

                @elseif($tool === 'watermark')
                <h4><i class="fas fa-copyright"></i> Watermark Settings</h4>
                <div class="form-group"><label>Text</label><input type="text" name="text" class="form-control" placeholder="e.g. © {{ \App\Models\Configuration::get('portal_name', config('app.name', 'Company')) }}" required></div>
                <div class="form-group"><label>Position</label>
                    <select name="position" class="form-control">
                        <option value="bottom-right">Bottom Right</option>
                        <option value="bottom-left">Bottom Left</option>
                        <option value="top-right">Top Right</option>
                        <option value="top-left">Top Left</option>
                        <option value="center">Center</option>
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Font Size</label><input type="number" name="size" class="form-control" value="36" min="10" max="200"></div>
                    <div class="form-group"><label>Color</label><input type="color" name="color" class="form-control" value="var(--card-bg)" style="height:42px;padding:4px;"></div>
                </div>
                <div class="form-group"><label>Opacity</label>
                    <div class="range-wrap"><input type="range" name="opacity" min="1" max="100" value="50" oninput="this.nextElementSibling.textContent=this.value+'%'"><span class="range-value">50%</span></div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-copyright"></i> Apply & Download</button>

                @elseif($tool === 'rotate')
                <h4><i class="fas fa-sync-alt"></i> Rotate & Flip</h4>
                <div class="form-group"><label>Rotation</label>
                    <div class="radio-group" id="angleGroup">
                        @foreach(['0'=>'0°','90'=>'90°','180'=>'180°','270'=>'270°'] as $val => $lbl)
                        <div class="radio-option {{ $val==='90'?'selected':'' }}" data-value="{{ $val }}" onclick="selectRadio('angleGroup',this)">{{ $lbl }}</div>
                        @endforeach
                    </div>
                    <input type="hidden" name="angle" value="90">
                </div>
                <div class="form-group"><label>Flip</label>
                    <select name="flip" class="form-control">
                        <option value="">No Flip</option>
                        <option value="h">Horizontal</option>
                        <option value="v">Vertical</option>
                        <option value="both">Both</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-sync-alt"></i> Rotate & Download</button>
                @endif
            </div>
        </div>
    </form>
</div></div>
</div>
@endforeach

<div class="toast" id="toast"></div>
@endsection

@push('scripts')
<script>
const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
const endpoints = {
    resize: '{{ route("admin.image-tools.resize") }}',
    crop: '{{ route("admin.image-tools.crop") }}',
    convert: '{{ route("admin.image-tools.convert") }}',
    compress: '{{ route("admin.image-tools.compress") }}',
    watermark: '{{ route("admin.image-tools.watermark") }}',
    rotate: '{{ route("admin.image-tools.rotate") }}',
    info: '{{ route("admin.image-tools.info") }}',
};

function switchTab(name, el) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
    document.getElementById('tab-' + name).classList.add('active');
}

function selectRadio(groupId, el) {
    const group = document.getElementById(groupId);
    group.querySelectorAll('.radio-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    const hidden = group.parentElement.querySelector('input[type="hidden"]');
    if (hidden) hidden.value = el.dataset.value;
}

// Upload preview for all tabs
['Resize','Crop','Convert','Compress','Watermark','Rotate'].forEach(tab => {
    const input = document.getElementById('img' + tab);
    const area = document.getElementById('upload' + tab);
    if (!input || !area) return;

    input.addEventListener('change', function() { if (this.files.length) showPreview(area, this.files[0], tab); });
    ['dragenter','dragover'].forEach(e => area.addEventListener(e, ev => { ev.preventDefault(); area.classList.add('dragover'); }));
    ['dragleave','drop'].forEach(e => area.addEventListener(e, ev => { ev.preventDefault(); area.classList.remove('dragover'); }));
    area.addEventListener('drop', ev => {
        if (ev.dataTransfer.files.length) { input.files = ev.dataTransfer.files; showPreview(area, ev.dataTransfer.files[0], tab); }
    });
});

function showPreview(area, file, tab) {
    const reader = new FileReader();
    reader.onload = e => {
        area.innerHTML = `<div class="preview-wrap"><img src="${e.target.result}" class="preview-img"></div>`;
        area.onclick = () => document.getElementById('img' + tab).click();
    };
    reader.readAsDataURL(file);

    if (tab === 'Resize') {
        const fd = new FormData();
        fd.append('image', file);
        fd.append('_token', csrfToken);
        fetch(endpoints.info, { method: 'POST', body: fd })
        .then(r => r.json()).then(d => {
            if (d.success) {
                const info = document.getElementById('infoResize');
                info.style.display = 'block';
                info.innerHTML = `
                    <div class="img-info-row"><span class="img-info-label">Dimensions</span><span class="img-info-value">${d.width} × ${d.height}</span></div>
                    <div class="img-info-row"><span class="img-info-label">Size</span><span class="img-info-value">${d.size_human}</span></div>
                    <div class="img-info-row"><span class="img-info-label">Format</span><span class="img-info-value">${d.extension.toUpperCase()}</span></div>
                    <div class="img-info-row"><span class="img-info-label">MIME</span><span class="img-info-value">${d.mime_type}</span></div>`;
            }
        }).catch(() => {});
    }
}

// Form submissions
const forms = { resizeForm:'resize', cropForm:'crop', convertForm:'convert', compressForm:'compress', watermarkForm:'watermark', rotateForm:'rotate' };
Object.keys(forms).forEach(formId => {
    const form = document.getElementById(formId);
    if (!form) return;
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const tool = forms[formId];
        const tabName = tool.charAt(0).toUpperCase() + tool.slice(1);
        const fileInput = document.getElementById('img' + tabName);
        if (!fileInput || !fileInput.files.length) { showToast('Please select an image first.', 'error'); return; }

        const formData = new FormData(form);
        const loader = document.getElementById('load' + tabName);
        if (loader) loader.classList.add('show');

        fetch(endpoints[tool], { method: 'POST', headers: { 'X-Requested-With': 'XMLHttpRequest' }, body: formData })
        .then(response => {
            if (loader) loader.classList.remove('show');
            if (!response.ok) return response.json().then(d => { throw new Error(d.message || 'Processing failed.'); });
            const disposition = response.headers.get('Content-Disposition');
            let filename = 'processed_image';
            if (disposition) { const m = disposition.match(/filename="?(.+?)"?$/); if (m) filename = m[1]; }
            return response.blob().then(blob => {
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = filename;
                document.body.appendChild(a); a.click(); document.body.removeChild(a);
                URL.revokeObjectURL(a.href);
                showToast('Image processed and downloaded!', 'success');
            });
        })
        .catch(err => { if (loader) loader.classList.remove('show'); showToast(err.message || 'Processing failed.', 'error'); });
    });
});

function showToast(msg, type) {
    const t = document.getElementById('toast');
    t.className = `toast ${type} show`;
    t.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${msg}`;
    setTimeout(() => t.classList.remove('show'), 3500);
}
</script>
@endpush
