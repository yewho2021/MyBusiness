@extends('admin.layouts.app')
@section('title', 'Admin List')

@section('content')
<div class="sc-page-header">
    <h2 class="sc-page-title">Admin Users</h2>
    <x-button icon="fas fa-plus" onclick="scOpenModal('createAdminModal')">Add Admin</x-button>
</div>

@if(session('success'))
    <x-alert type="success" :dismissible="true">{{ session('success') }}</x-alert>
@endif
@if(session('error'))
    <x-alert type="danger" :dismissible="true">{{ session('error') }}</x-alert>
@endif

<x-card :padding="true">
    <div class="sc-overflow-x">
        <table class="sc-table" id="adminsTable" style="width:100%;">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Last Login</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</x-card>

{{-- Create Modal --}}
<x-modal id="createAdminModal" title="Add New Admin" size="md">
    <form action="{{ route('admin.users.store') }}" method="POST">
        @csrf
        <x-form-group label="Name" name="name" :required="true">
            <x-input name="name" required />
        </x-form-group>
        <x-form-group label="Email" name="email" :required="true">
            <x-input type="email" name="email" required />
        </x-form-group>
        <x-form-group label="Username" name="username" :required="true">
            <x-input name="username" required />
        </x-form-group>
        <x-form-group label="Password" name="password" :required="true">
            <x-input type="password" name="password" required minlength="8" />
        </x-form-group>
        <x-form-group label="Confirm Password" name="password_confirmation" :required="true">
            <x-input type="password" name="password_confirmation" required minlength="8" />
        </x-form-group>
        <x-form-group label="Role" name="role_id" :required="true">
            <x-select name="role_id" :options="$roles->pluck('name', 'id')->toArray()" placeholder="Select Role" required />
        </x-form-group>
        <div class="sc-form-group">
            <label class="sc-checkbox-label">
                <input type="checkbox" name="is_active" checked>
                <span>Active</span>
            </label>
        </div>
        <x-slot:footer>
            <x-button variant="secondary" onclick="scCloseModal('createAdminModal')">Cancel</x-button>
            <x-button type="submit">Create Admin</x-button>
        </x-slot:footer>
    </form>
</x-modal>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
@endpush

@push('scripts')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script>
    jQuery(document).ready(function() {
        const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

        jQuery('#adminsTable').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: '{{ route("admin.users.index") }}',
                type: 'GET',
            },
            columns: [
                { data: 'id', name: 'id', width: '50px' },
                {
                    data: 'name', name: 'name',
                    render: function(data, type, row) {
                        return '<div style="display:flex;align-items:center;gap:12px;"><div style="width:36px;height:36px;background:var(--c-primary,var(--c-danger));border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:600;font-size:14px;flex-shrink:0;">' + row.initial + '</div><span>' + data + '</span></div>';
                    }
                },
                { data: 'username', name: 'username' },
                { data: 'email', name: 'email' },
                {
                    data: 'role_name', name: 'role.name',
                    render: function(data, type, row) {
                        return '<span class="sc-badge sc-badge--' + (row.role_slug || 'default') + '">' + data + '</span>';
                    }
                },
                {
                    data: 'status_label', name: 'is_active',
                    render: function(data, type, row) {
                        var cls = row.is_active ? 'active' : 'inactive';
                        return '<span class="sc-badge sc-badge--' + cls + '">' + data + '</span>';
                    }
                },
                { data: 'last_login_formatted', name: 'datetime_lastlogin', searchable: false },
                {
                    data: 'actions', name: 'actions', orderable: false, searchable: false,
                    render: function(data, type, row) {
                        var editUrl = '{{ url("users") }}/' + row.id + '/edit';
                        var toggleUrl = '{{ url("users") }}/' + row.id + '/toggle-status';
                        var deleteUrl = '{{ url("users") }}/' + row.id;
                        var toggleIcon = row.is_active ? 'ban' : 'check';
                        var toggleTitle = row.is_active ? 'Deactivate' : 'Activate';

                        return '<div class="sc-actions">' +
                            '<a href="' + editUrl + '" class="sc-btn sc-btn--icon sc-btn--edit" title="Edit"><i class="fas fa-edit"></i></a>' +
                            '<form action="' + toggleUrl + '" method="POST" style="display:inline;"><input type="hidden" name="_token" value="' + csrfToken + '"><button type="submit" class="sc-btn sc-btn--icon sc-btn--toggle" title="' + toggleTitle + '"><i class="fas fa-' + toggleIcon + '"></i></button></form>' +
                            '<form action="' + deleteUrl + '" method="POST" style="display:inline;" onsubmit="return confirm(\'Delete this admin?\')"><input type="hidden" name="_token" value="' + csrfToken + '"><input type="hidden" name="_method" value="DELETE"><button type="submit" class="sc-btn sc-btn--icon sc-btn--delete" title="Delete"><i class="fas fa-trash"></i></button></form>' +
                            '</div>';
                    }
                },
            ],
            order: [[0, 'desc']],
            pageLength: 25,
            lengthMenu: [10, 25, 50, 100],
            language: {
                search: '',
                searchPlaceholder: 'Search admins...',
                lengthMenu: 'Show _MENU_ entries',
                info: 'Showing _START_ to _END_ of _TOTAL_ admins',
                emptyTable: 'No admin users found',
                processing: '<i class="fas fa-spinner fa-spin"></i> Loading...',
            },
            dom: '<"dt-top"lf>rt<"dt-bottom"ip>',
        });
    });
</script>
@endpush
