@extends('admin.layouts.app')
@section('title', 'Dashboard')

@push('styles')
<style>
.dash-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:24px}
.dash-header h1{font-size:22px;font-weight:700;color:var(--header-text,var(--text-heading));margin-bottom:4px}
.dash-header p{font-size:13px;color:var(--text-muted)}

.welcome-banner{background:#111;border-radius:var(--card-radius,12px);padding:24px 28px;margin-bottom:24px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.welcome-left h2{font-size:20px;font-weight:700;color:#fff;margin-bottom:6px}
.welcome-left p{font-size:13px;color:var(--text-faint)}
.welcome-left p strong{color:var(--input-border)}
.welcome-right{display:flex;gap:10px;flex-wrap:wrap}
.welcome-badge{padding:6px 14px;border-radius:8px;font-size:12px;font-weight:600;display:inline-flex;align-items:center;gap:6px}
.welcome-badge.role{background:rgba(255,255,255,.1);color:var(--border-color)}
.welcome-badge.time{background:rgba(255,255,255,.06);color:var(--text-faint);font-weight:400}

.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px}
@media(max-width:1200px){.stats-row{grid-template-columns:repeat(2,1fr)}}
@media(max-width:640px){.stats-row{grid-template-columns:1fr}}
.stat-card{background:var(--card-bg,#fff);border-radius:var(--card-radius,12px);padding:20px 24px;border:1px solid var(--border-light);transition:all .2s}
.stat-card:hover{box-shadow:0 4px 12px rgba(0,0,0,.06);border-color:var(--border-color)}
.stat-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.stat-icon{width:42px;height:42px;border-radius:var(--card-radius,10px);display:flex;align-items:center;justify-content:center;font-size:18px}
.stat-icon.blue{background:var(--c-secondary-light);color:var(--c-secondary,var(--c-secondary))}
.stat-icon.green{background:var(--c-success-light);color:var(--c-success,var(--c-success))}
.stat-icon.amber{background:var(--c-warning-light);color:var(--c-warning,var(--c-warning))}
.stat-icon.purple{background:var(--c-purple-light);color:var(--c-info,var(--c-purple))}
.stat-badge{font-size:11px;font-weight:600;padding:3px 8px;border-radius:6px;display:inline-flex;align-items:center;gap:3px}
.stat-badge.up{background:var(--c-success-light);color:var(--c-success,var(--c-success))}
.stat-badge.neutral{background:var(--table-header-bg,var(--table-header-bg));color:var(--text-muted)}
.stat-value{font-size:26px;font-weight:700;color:var(--header-text,var(--text-heading));line-height:1.2;margin-bottom:4px}
.stat-label{font-size:13px;color:var(--text-muted);font-weight:500}

.card-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:24px}
@media(max-width:900px){.card-grid{grid-template-columns:1fr}}
.card-grid.three{grid-template-columns:1fr 1fr 1fr}
@media(max-width:1100px){.card-grid.three{grid-template-columns:1fr 1fr}}
@media(max-width:700px){.card-grid.three{grid-template-columns:1fr}}

.card{background:var(--card-bg,#fff);border-radius:var(--card-radius,12px);border:1px solid var(--border-light);overflow:hidden}
.card:hover{border-color:var(--border-color)}
.card-head{padding:18px 22px;display:flex;justify-content:space-between;align-items:center}
.card-title{font-size:15px;font-weight:600;color:var(--header-text,var(--text-heading));display:flex;align-items:center;gap:8px}
.card-title i{color:var(--text-faint);font-size:14px}
.card-subtitle{font-size:12px;color:var(--text-faint);font-weight:400;margin-left:4px}
.card-action{font-size:12px;color:var(--c-secondary,var(--c-secondary));text-decoration:none;font-weight:500;display:inline-flex;align-items:center;gap:4px}
.card-action:hover{color:var(--c-secondary)}
.card-body{padding:0 22px 18px}
.card-body.no-pad{padding:0}

.card-table{width:100%;border-collapse:collapse}
.card-table th{text-align:left;padding:10px 22px;font-size:11px;font-weight:600;color:var(--text-faint);text-transform:uppercase;letter-spacing:.4px;background:var(--hover-bg);border-top:1px solid var(--border-light,var(--border-light));border-bottom:1px solid var(--border-light,var(--border-light))}
.card-table td{padding:12px 22px;font-size:13px;color:var(--text-body);border-bottom:1px solid var(--table-header-bg)}
.card-table tbody tr:last-child td{border-bottom:none}
.card-table tbody tr:hover td{background:var(--hover-bg)}

.badge{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600}
.badge.green{background:var(--c-success-light);color:var(--c-success,var(--c-success))}
.badge.red{background:var(--c-danger-light);color:var(--c-primary,var(--c-danger))}
.badge.blue{background:var(--c-secondary-light);color:var(--c-secondary,var(--c-secondary))}
.badge.amber{background:var(--c-warning-light);color:var(--c-warning,var(--c-warning))}
.badge.gray{background:var(--hover-bg);color:var(--text-muted)}
.badge.purple{background:var(--c-purple-light);color:var(--c-info,var(--c-purple))}

.progress-bar{width:100%;height:6px;background:var(--border-light,var(--border-light));border-radius:3px;overflow:hidden}
.progress-fill{height:100%;border-radius:3px;transition:width .6s ease}
.progress-fill.blue{background:var(--c-secondary,var(--c-secondary))}

.info-list{display:flex;flex-direction:column;gap:0}
.info-row{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--table-header-bg)}
.info-row:last-child{border-bottom:none}
.info-label{font-size:13px;color:var(--text-muted);display:flex;align-items:center;gap:8px}
.info-label i{width:16px;color:var(--text-faint);text-align:center}
.info-value{font-size:13px;color:var(--header-text,var(--text-heading));font-weight:600}

.quick-links{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}
.quick-link{display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:8px;border:1px solid var(--border-light);text-decoration:none;color:var(--text-body);font-size:13px;font-weight:500;transition:all .15s}
.quick-link:hover{background:var(--table-header-bg,var(--table-header-bg));border-color:var(--border-color)}
.quick-link i{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0}
.quick-link .ql-text{display:flex;flex-direction:column}
.quick-link .ql-text span:first-child{font-weight:600;color:var(--header-text,var(--text-heading))}
.quick-link .ql-text span:last-child{font-size:11px;color:var(--text-faint);font-weight:400}

/* Control Panel */
.cp-section{margin-bottom:24px}
.cp-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;cursor:pointer;user-select:none}
.cp-header h3{font-size:16px;font-weight:700;color:var(--header-text,var(--text-heading));display:flex;align-items:center;gap:10px}
.cp-header h3 i{color:var(--text-faint);font-size:14px}
.cp-toggle{font-size:12px;color:var(--text-faint);display:flex;align-items:center;gap:6px;padding:6px 12px;border-radius:6px;border:1px solid var(--border-color,var(--border-color));background:#fff}
.cp-toggle:hover{background:var(--table-header-bg,var(--table-header-bg))}
.cp-body{transition:all .3s ease}
.cp-body.collapsed{display:none}
.cp-group{margin-bottom:18px}
.cp-group-title{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--text-faint);margin-bottom:10px;padding-left:4px;display:flex;align-items:center;gap:8px}
.cp-group-title::after{content:'';flex:1;height:1px;background:var(--border-light,var(--border-light))}
.cp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px}
@media(max-width:640px){.cp-grid{grid-template-columns:repeat(2,1fr)}}
.cp-item{display:flex;flex-direction:column;align-items:center;gap:8px;padding:16px 10px;border-radius:var(--card-radius,10px);border:1px solid var(--border-light);background:var(--card-bg,#fff);text-decoration:none;color:var(--text-body);transition:all .15s;text-align:center}
.cp-item:hover{border-color:var(--border-color);box-shadow:0 2px 8px rgba(0,0,0,.04);transform:translateY(-1px)}
.cp-item-icon{width:40px;height:40px;border-radius:var(--card-radius,10px);display:flex;align-items:center;justify-content:center;font-size:16px}
.cp-item-label{font-size:12px;font-weight:600;line-height:1.3}
</style>
@endpush

@section('content')
<div class="welcome-banner">
    <div class="welcome-left">
        <h2>Welcome back, {{ $admin->name ?? 'Admin' }}</h2>
        <p>Logged in as <strong>{{ $admin->role->name ?? 'User' }}</strong> &middot; Here's your system overview</p>
    </div>
    <div class="welcome-right">
        <span class="welcome-badge role"><i class="fas fa-shield-alt"></i> {{ $admin->role->name ?? 'User' }}</span>
        <span class="welcome-badge time"><i class="fas fa-clock"></i> {{ now()->format('D, d M Y') }}</span>
    </div>
</div>

<div class="stats-row">
    <div class="stat-card">
        <div class="stat-top">
            <div class="stat-icon blue"><i class="fas fa-table"></i></div>
            <span class="stat-badge neutral"><i class="fas fa-database"></i> {{ $dbName }}</span>
        </div>
        <div class="stat-value">{{ number_format($totalTables) }}</div>
        <div class="stat-label">Database Tables</div>
    </div>
    <div class="stat-card">
        <div class="stat-top">
            <div class="stat-icon green"><i class="fas fa-hdd"></i></div>
            <span class="stat-badge up"><i class="fas fa-check-circle"></i> Active</span>
        </div>
        <div class="stat-value">{{ $totalDbSize >= 1048576 ? number_format($totalDbSize/1048576,1).' MB' : number_format($totalDbSize/1024,1).' KB' }}</div>
        <div class="stat-label">Database Size</div>
    </div>
    <div class="stat-card">
        <div class="stat-top">
            <div class="stat-icon amber"><i class="fas fa-layer-group"></i></div>
        </div>
        <div class="stat-value">{{ number_format($totalRows) }}</div>
        <div class="stat-label">Total Rows</div>
    </div>
    <div class="stat-card">
        <div class="stat-top">
            <div class="stat-icon purple"><i class="fas fa-plug"></i></div>
        </div>
        <div class="stat-value">{{ $savedConnections }}</div>
        <div class="stat-label">Saved Connections</div>
    </div>
</div>

{{-- ── Control Panel (cPanel-style icon grid) ──────── --}}
@if(!empty($controlPanel))
<div class="cp-section">
    <div class="cp-header" onclick="document.getElementById('cpBody').classList.toggle('collapsed');this.querySelector('.cp-arrow').classList.toggle('fa-chevron-down');this.querySelector('.cp-arrow').classList.toggle('fa-chevron-up')">
        <h3><i class="fas fa-th"></i> Control Panel</h3>
        <span class="cp-toggle"><span>Toggle</span> <i class="fas fa-chevron-up cp-arrow"></i></span>
    </div>
    <div id="cpBody" class="cp-body">
        @foreach($controlPanel as $group)
            <div class="cp-group">
                <div class="cp-group-title">{{ $group['group_title'] }}</div>
                <div class="cp-grid">
                    @foreach($group['items'] as $item)
                        <a href="{{ $item['url'] }}" class="cp-item">
                            <div class="cp-item-icon" style="background:{{ $group['color']['bg'] }};color:{{ $group['color']['fg'] }}">
                                <i class="{{ $item['icon'] }}"></i>
                            </div>
                            <span class="cp-item-label">{{ $item['title'] }}</span>
                        </a>
                    @endforeach
                </div>
            </div>
        @endforeach
    </div>
</div>
@endif

<div class="card-grid">
    <div class="card">
        <div class="card-head">
            <span class="card-title"><i class="fas fa-code-branch"></i> Recent Changes <span class="card-subtitle">{{ $totalChangelogs }} total</span></span>
            <a href="{{ route('admin.changelog.index') }}" class="card-action">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-body no-pad">
            <table class="card-table">
                <thead><tr><th>Version</th><th>Title</th><th>Type</th><th>Date</th></tr></thead>
                <tbody>
                @forelse($recentChangelogs as $log)
                    <tr>
                        <td><span class="badge blue">v{{ $log->version }}</span></td>
                        <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">{{ $log->title }}</td>
                        <td><span class="badge {{ $log->app_type === 'office' ? 'purple' : 'green' }}">{{ $log->app_type }}</span></td>
                        <td style="color:var(--text-faint);font-size:12px">{{ \Carbon\Carbon::parse($log->created_at)->format('d M Y') }}</td>
                    </tr>
                @empty
                    <tr><td colspan="4" style="text-align:center;color:var(--text-faint);padding:24px">No changelogs yet</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-head">
            <span class="card-title"><i class="fas fa-shield-alt"></i> Recent Backups</span>
            <a href="{{ route('admin.backup.history') }}" class="card-action">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-body no-pad">
            <table class="card-table">
                <thead><tr><th>Backup</th><th>Status</th><th>Files</th><th>Date</th></tr></thead>
                <tbody>
                @forelse($recentBackups as $bk)
                    <tr>
                        <td style="font-weight:500">{{ \Illuminate\Support\Str::limit($bk->folder_name ?? 'Manual', 28) }}</td>
                        <td>
                            @if($bk->status === 'completed')<span class="badge green"><i class="fas fa-check"></i> Done</span>
                            @elseif($bk->status === 'failed')<span class="badge red"><i class="fas fa-times"></i> Failed</span>
                            @elseif($bk->status === 'running')<span class="badge amber"><i class="fas fa-spinner fa-spin"></i> Running</span>
                            @else<span class="badge gray">{{ $bk->status }}</span>@endif
                        </td>
                        <td>{{ number_format($bk->total_files) }}</td>
                        <td style="color:var(--text-faint);font-size:12px">{{ $bk->created_at?->format('d M Y H:i') }}</td>
                    </tr>
                @empty
                    <tr><td colspan="4" style="text-align:center;color:var(--text-faint);padding:24px">No backups yet</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card-grid three">
    <div class="card">
        <div class="card-head"><span class="card-title"><i class="fas fa-bolt"></i> Quick Actions</span></div>
        <div class="card-body">
            <div class="quick-links">
                <a href="{{ route('admin.database.connections.index') }}" class="quick-link">
                    <i style="background:var(--c-secondary-light);color:var(--c-secondary,var(--c-secondary))" class="fas fa-database"></i>
                    <div class="ql-text"><span>Database</span><span>Manage connections</span></div>
                </a>
                <a href="{{ route('admin.backup.index') }}" class="quick-link">
                    <i style="background:var(--c-success-light);color:var(--c-success,var(--c-success))" class="fas fa-shield-alt"></i>
                    <div class="ql-text"><span>Backup</span><span>Run & manage</span></div>
                </a>
                <a href="{{ route('admin.filemanager.index') }}" class="quick-link">
                    <i style="background:var(--c-warning-light);color:var(--c-warning,var(--c-warning))" class="fas fa-folder"></i>
                    <div class="ql-text"><span>File Manager</span><span>Browse files</span></div>
                </a>
                <a href="{{ route('admin.users.index') }}" class="quick-link">
                    <i style="background:var(--c-purple-light);color:var(--c-info,var(--c-purple))" class="fas fa-users"></i>
                    <div class="ql-text"><span>Users</span><span>Manage admins</span></div>
                </a>
                <a href="{{ route('admin.menus.index') }}" class="quick-link">
                    <i style="background:var(--c-info-light);color:var(--c-info)" class="fas fa-sitemap"></i>
                    <div class="ql-text"><span>Menus</span><span>Navigation setup</span></div>
                </a>
                <a href="{{ route('admin.changelog.index') }}" class="quick-link">
                    <i style="background:var(--c-danger-light);color:var(--c-danger)" class="fas fa-history"></i>
                    <div class="ql-text"><span>Changelog</span><span>Version history</span></div>
                </a>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-head"><span class="card-title"><i class="fas fa-server"></i> Server Info</span></div>
        <div class="card-body">
            <div class="info-list">
                <div class="info-row"><span class="info-label"><i class="fab fa-php"></i> PHP Version</span><span class="info-value">{{ $phpVersion }}</span></div>
                <div class="info-row"><span class="info-label"><i class="fab fa-laravel"></i> Laravel</span><span class="info-value">{{ $laravelVersion }}</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-globe"></i> Server</span><span class="info-value" style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="{{ $serverSoftware }}">{{ \Illuminate\Support\Str::limit($serverSoftware, 28) }}</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-database"></i> Database</span><span class="info-value">{{ $dbName }}</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-network-wired"></i> DB Host</span><span class="info-value">{{ config('database.connections.mysql.host') }}</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-users"></i> Admins</span><span class="info-value">{{ $totalAdmins }}</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-user-tag"></i> Roles</span><span class="info-value">{{ $totalRoles }}</span></div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-head"><span class="card-title"><i class="fas fa-heartbeat"></i> System Health</span></div>
        <div class="card-body">
            <div class="info-list">
                <div class="info-row"><span class="info-label"><i class="fas fa-database"></i> Database</span><span class="badge green"><i class="fas fa-check-circle"></i> Connected</span></div>
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-shield-alt"></i> Last Backup</span>
                    @if($lastBackup)<span class="badge {{ $lastBackup->status === 'completed' ? 'green' : 'amber' }}">{{ $lastBackup->created_at?->diffForHumans() }}</span>
                    @else<span class="badge gray">Never</span>@endif
                </div>
                <div class="info-row">
                    <span class="info-label"><i class="fas fa-hdd"></i> DB Size</span>
                    <div style="flex:1;max-width:140px;margin-left:auto">
                        <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:11px;color:var(--text-muted)">{{ $totalDbSize >= 1048576 ? number_format($totalDbSize/1048576,1).' MB' : number_format($totalDbSize/1024,1).' KB' }}</span></div>
                        <div class="progress-bar"><div class="progress-fill blue" style="width:{{ min(100, $totalDbSize/1048576/100*100) }}%"></div></div>
                    </div>
                </div>
                <div class="info-row"><span class="info-label"><i class="fas fa-table"></i> Tables</span><span class="info-value">{{ $totalTables }}</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-plug"></i> Connections</span><span class="info-value">{{ $savedConnections }}</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-sitemap"></i> Menu Items</span><span class="info-value">{{ $totalMenus }}</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-code-branch"></i> Changelog</span><span class="info-value">{{ $totalChangelogs }} entries</span></div>
            </div>
        </div>
    </div>
</div>

{{-- ── Row 4: Disk Usage + Recent Logins ──────────── --}}
<div class="card-grid" style="margin-bottom:24px">
    <div class="card">
        <div class="card-head"><span class="card-title"><i class="fas fa-hdd"></i> Disk usage</span></div>
        <div class="card-body">
            @php
                $fmt = function($bytes) { 
                    if ($bytes >= 1073741824) return number_format($bytes/1073741824, 1).' GB';
                    if ($bytes >= 1048576) return number_format($bytes/1048576, 1).' MB';
                    return number_format($bytes/1024, 1).' KB';
                };
                $pct = $diskStats['percent'];
                $barColor = $pct > 90 ? 'var(--c-danger)' : ($pct > 75 ? 'var(--c-warning)' : 'var(--c-success)');
            @endphp
            <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:12px">
                <span style="font-size:26px;font-weight:700;color:var(--header-text,var(--text-heading))">{{ $pct }}%</span>
                <span style="font-size:12px;color:var(--text-muted)">{{ $fmt($diskStats['used']) }} / {{ $fmt($diskStats['total']) }}</span>
            </div>
            <div class="progress-bar" style="margin-bottom:16px"><div class="progress-fill" style="width:{{ min(100,$pct) }}%;background:{{ $barColor }}"></div></div>
            <div class="info-list">
                <div class="info-row"><span class="info-label">Free space</span><span class="info-value">{{ $fmt($diskStats['free']) }}</span></div>
                <div class="info-row"><span class="info-label">Storage folder</span><span class="info-value">{{ $fmt($diskStats['storage_size']) }}</span></div>
                <div class="info-row"><span class="info-label">Database</span><span class="info-value">{{ $totalDbSize >= 1048576 ? number_format($totalDbSize/1048576,1).' MB' : number_format($totalDbSize/1024,1).' KB' }}</span></div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-head">
            <span class="card-title"><i class="fas fa-sign-in-alt"></i> Recent logins</span>
            <a href="{{ route('admin.admin-log.index') }}" class="card-action">View all <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-body no-pad">
            <table class="card-table">
                <thead><tr><th>Admin</th><th>Status</th><th>IP</th><th>When</th></tr></thead>
                <tbody>
                @forelse($recentLogins as $login)
                    <tr>
                        <td style="font-weight:600">{{ $login->admin_name ?? '—' }}</td>
                        <td>
                            @if($login->status === 'active')
                                <span class="badge green"><i class="fas fa-check-circle"></i> Active</span>
                            @elseif(str_starts_with($login->status ?? '', 'failed'))
                                <span class="badge red"><i class="fas fa-times-circle"></i> Failed</span>
                            @else
                                <span class="badge gray">{{ ucfirst($login->status ?? '—') }}</span>
                            @endif
                        </td>
                        <td style="font-size:11px;color:var(--text-muted);font-family:monospace">{{ $login->ip_address ?? '—' }}</td>
                        <td style="font-size:11px;color:var(--text-faint)">{{ $login->login_at ? \Carbon\Carbon::parse($login->login_at)->diffForHumans() : '—' }}</td>
                    </tr>
                @empty
                    <tr><td colspan="4" style="text-align:center;color:var(--text-faint);padding:20px">No login records</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- ── Row 5: Activity Timeline ───────────────────── --}}
@if(!empty($recentActivities) && count($recentActivities) > 0)
<div class="card" style="margin-bottom:24px">
    <div class="card-head">
        <span class="card-title"><i class="fas fa-stream"></i> Activity timeline</span>
        <a href="{{ route('admin.activity-log.index') }}" class="card-action">View all <i class="fas fa-arrow-right"></i></a>
    </div>
    <div class="card-body" style="padding-top:4px">
        <div style="position:relative;padding-left:20px">
            <div style="position:absolute;left:6px;top:8px;bottom:8px;width:2px;background:var(--border-light,var(--border-light));border-radius:1px"></div>
            @foreach($recentActivities as $act)
            <div style="position:relative;padding:8px 0 8px 16px;display:flex;align-items:flex-start;gap:12px">
                <div style="position:absolute;left:-3px;top:14px;width:10px;height:10px;border-radius:50%;border:2px solid {{ $act->event === 'deleted' ? 'var(--c-danger)' : ($act->event === 'created' ? 'var(--c-success)' : 'var(--c-secondary)') }};background:var(--card-bg,#fff);z-index:1"></div>
                <div style="flex:1;min-width:0">
                    <div style="font-size:13px;color:var(--text-body)">
                        <strong>{{ ucfirst($act->event ?? 'action') }}</strong>
                        @if($act->subject_type)
                            <span style="color:var(--text-muted)">{{ class_basename($act->subject_type) }}</span>
                        @endif
                        @if($act->description)
                            <span style="color:var(--text-faint)">— {{ \Illuminate\Support\Str::limit($act->description, 60) }}</span>
                        @endif
                    </div>
                    <div style="font-size:11px;color:var(--text-faint);margin-top:2px">{{ $act->created_at?->diffForHumans() }}</div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>
@endif
@endsection
