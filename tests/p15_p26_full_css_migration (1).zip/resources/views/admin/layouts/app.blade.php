@php
    $__cfg = \App\Models\Configuration::getAll();
    $__fontUrl = \App\Models\Configuration::googleFontUrl();
    $__portalName = $__cfg['portal_name'] ?? 'Admin Portal';
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') - {{ $__portalName }}</title>
    @if(!empty($__cfg['favicon']))
    <link rel="icon" href="{{ asset($__cfg['favicon']) }}">
    @endif
    <link href="{{ $__fontUrl }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('css/components.css') }}">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            {!! \App\Models\Configuration::cssVariables() !!}
        }
        body { font-family: var(--font-family, 'Inter', sans-serif); background: var(--body-bg, var(--border-light)); min-height: 100vh; font-size: var(--fs-base, 14px); }
        .admin-wrapper { display: flex; min-height: 100vh; }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: var(--sidebar-bg);
            z-index: 1000;
            overflow-y: auto;
            transition: transform .3s ease;
        }
        .main-wrapper {
            margin-left: var(--sidebar-width);
            flex: 1;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            transition: margin-left .3s ease;
        }
        .header {
            height: var(--header-height);
            background: var(--header-bg, #fff);
            border-bottom: 1px solid var(--header-border, var(--border-color));
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 var(--content-padding, 24px);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .main-content { flex: 1; padding: var(--content-padding, 24px); }
        .footer {
            height: 50px;
            background: var(--card-bg, #fff);
            border-top: 1px solid var(--border-color, var(--border-color));
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 var(--content-padding, 24px);
            font-size: var(--fs-sm, 13px);
            color: var(--text-muted);
        }

        /* Hamburger */
        .hamburger { display:none; background:none; border:none; color:var(--header-text,var(--text-heading)); font-size:20px; cursor:pointer; padding:8px; border-radius:8px; margin-right:12px; }
        .hamburger:hover { background:var(--border-light); }

        /* Overlay */
        .sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(15,23,42,.5); backdrop-filter:blur(2px); z-index:999; }
        .sidebar-overlay.show { display:block; }

        /* Sidebar close btn (mobile only) */
        .sidebar-close { display:none; position:absolute; top:16px; right:16px; background:rgba(255,255,255,.1); border:none; color:#fff; width:32px; height:32px; border-radius:8px; cursor:pointer; font-size:14px; z-index:10; }
        .sidebar-close:hover { background:rgba(255,255,255,.2); }

        /* ── RESPONSIVE: Tablet (≤1024px) ────────────── */
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.show { transform: translateX(0); }
            .sidebar-close { display:flex; align-items:center; justify-content:center; }
            .main-wrapper { margin-left: 0; }
            .hamburger { display:inline-flex; }
            .main-content { padding: 16px; }
            .header { padding: 0 16px; }
            .footer { padding: 0 16px; }

            /* Database Query: sidebar+main layout */
            .db-container { flex-direction:column !important; height:auto !important; }
            .db-sidebar { width:100% !important; min-width:100% !important; max-height:250px; border-right:none !important; border-bottom:1px solid var(--border-color); }
            .db-main { min-width:0 !important; }

            /* File Manager: full-width on tablet */
            .fm-wrapper { overflow:visible !important; }
            #fm-main-block .fm-body > .row { flex-direction:column !important; }
            #fm-main-block .fm-body > .row > [class*="col"] { width:100% !important; max-width:100% !important; flex:none !important; }

            /* Stats grids: 2 cols */
            .stats-row, .stat-grid, .stats-grid { grid-template-columns:repeat(2,1fr) !important; }
        }

        /* ── RESPONSIVE: Mobile (≤768px) ─────────────── */
        @media (max-width: 768px) {
            .main-content { padding: 12px; }
            .header { padding: 0 12px; gap:8px; }
            .footer { padding: 0 12px; font-size:11px; flex-direction:column; height:auto; padding:10px 12px; gap:2px; }
            .page-title { font-size:15px !important; }

            /* User dropdown: hide text */
            .user-info { display:none !important; }
            .user-btn { padding:6px !important; }

            /* ── Tables ── */
            .table-responsive, .table-wrap { overflow-x:auto; -webkit-overflow-scrolling:touch; }
            table:not(.sp-table) { min-width:500px; }
            th, td { padding:8px 10px !important; font-size:12px !important; }

            /* ── Page headers ── */
            .page-header, .cfg-header { flex-direction:column !important; align-items:flex-start !important; gap:10px !important; }
            .page-header h2, .cfg-header h2 { font-size:18px !important; }
            .header-actions, .cfg-header-right { width:100% !important; display:flex !important; flex-wrap:wrap !important; gap:6px !important; }

            /* ── Panels ── */
            .panels { grid-template-columns:1fr !important; }

            /* ── Buttons ── */
            .btn { padding:8px 14px !important; font-size:12px !important; }
            .btn-sm { padding:6px 10px !important; font-size:11px !important; }

            /* ── Cards ── */
            .sp-card, .em-card, .cc-card, .card { padding:14px !important; }

            /* ── Configuration: tabs → horizontal scroll ── */
            .cfg-tabs { overflow-x:auto !important; flex-wrap:nowrap !important; -webkit-overflow-scrolling:touch; padding-bottom:4px; }
            .cfg-tab-btn { white-space:nowrap !important; flex-shrink:0 !important; font-size:12px !important; padding:8px 14px !important; }
            .cfg-sidebar { width:100% !important; min-width:100% !important; }
            .cfg-container { flex-direction:column !important; }
            .cfg-tab { border-left:none !important; white-space:nowrap; }
            .cfg-grid { grid-template-columns:1fr !important; }

            /* ── All modals ── */
            .sp-modal, .modal, .fm-modal { width:95vw !important; max-width:95vw !important; }
            .modal-lg { max-width:95vw !important; }

            /* ── Grids: force 1 col ── */
            .cc-grid, .form-row, .form-grid { grid-template-columns:1fr !important; }

            /* ── Stats: 2 cols then 1 ── */
            .stats-row, .stat-grid, .stats-grid { grid-template-columns:repeat(2,1fr) !important; gap:8px !important; }
            .stat-card { padding:12px !important; }
            .stat-value { font-size:18px !important; }

            /* ── Panel actions: wrap ── */
            .panel-actions { flex-wrap:wrap !important; gap:4px !important; }

            /* ── Forms: full width ── */
            input[type="text"], input[type="email"], input[type="password"], input[type="number"], input[type="url"],
            input[type="search"], input[type="tel"], select, textarea, .form-control {
                width:100% !important; min-width:0 !important; max-width:100% !important;
            }
            .em-layout input, .em-layout select { width:100% !important; }
            .color-hex-wrap { width:120px !important; }
            .num-input-wrap input { width:70px !important; }

            /* ── System Patch ── */
            .sp-btn-group { flex-direction:column !important; }
            .sp-btn-group .sp-btn { width:100% !important; justify-content:center !important; }
            .sp-stats { flex-direction:column !important; }
            .sp-drop { padding:32px 16px !important; }
            .sp-drop-icon { font-size:32px !important; }
            .sp-drop-text { font-size:13px !important; }
            .sp-table td, .sp-table th { padding:6px 8px !important; font-size:11px !important; }

            /* ── Cache tab ── */
            .cc-grid { grid-template-columns:1fr !important; }
            .cc-summary-strip { flex-direction:column !important; gap:8px !important; }

            /* ── Database Manager ── */
            .db-tools { grid-template-columns:1fr !important; }
            .db-sidebar { max-height:200px; }
            .result-table { font-size:11px !important; }
            .result-table td, .result-table th { padding:6px 8px !important; }
            .db-statusbar { flex-wrap:wrap !important; font-size:11px !important; gap:6px !important; }
            .nav-pills, .nav-pill { flex-wrap:nowrap !important; overflow-x:auto !important; -webkit-overflow-scrolling:touch; }
            .nav-pill { white-space:nowrap !important; flex-shrink:0 !important; font-size:12px !important; }

            /* ── Database table view ── */
            .table-header { flex-direction:column !important; gap:8px !important; }
            .table-info { flex-direction:column !important; gap:4px !important; }
            .filter-row { flex-direction:column !important; gap:6px !important; }
            .filter-row select, .filter-row input { width:100% !important; }

            /* ── File Manager ── */
            .fm-action-bar { flex-wrap:wrap !important; gap:6px !important; }
            .fm-path-display { min-width:0 !important; width:100% !important; font-size:11px !important; }
            .fm-statusbar { flex-wrap:wrap !important; font-size:10px !important; }
            .editor-tabs { overflow-x:auto !important; flex-wrap:nowrap !important; }
            .editor-tab { white-space:nowrap !important; flex-shrink:0 !important; }

            /* ── Menus page ── */
            .menu-item { padding:10px 12px !important; }
            .item-meta { display:none !important; }
            .btn-action { width:28px !important; height:28px !important; }

            /* ── Backup pages ── */
            .backup-grid, .job-grid { grid-template-columns:1fr !important; }
            .backup-header { flex-direction:column !important; gap:8px !important; }
            .backup-actions { width:100% !important; flex-wrap:wrap !important; }
            .info-grid, .info-row { grid-template-columns:1fr !important; }
            .info-row { flex-direction:column !important; gap:4px !important; }
            .info-label { min-width:0 !important; }

            /* ── Changelog ── */
            .changelog-item { padding:14px !important; }
            .changelog-header { flex-direction:column !important; gap:6px !important; }
            .changelog-meta { flex-wrap:wrap !important; gap:6px !important; }
            .changelog-table { min-width:500px; }

            /* ── Permissions ── */
            .perm-table-wrap, .permission-container { overflow-x:auto !important; -webkit-overflow-scrolling:touch; }
            .perm-grid { grid-template-columns:1fr !important; }
            .permission-section { min-width:600px; }

            /* ── Users/Roles ── */
            .user-grid, .role-grid { grid-template-columns:1fr !important; }
            .user-card, .role-card { padding:14px !important; }
            .user-actions, .role-actions, .action-buttons { flex-wrap:wrap !important; gap:4px !important; }
            .user-info-cell .avatar { width:30px !important; height:30px !important; font-size:12px !important; }

            /* ── Database Connections ── */
            .conn-grid { grid-template-columns:1fr !important; }
            .conn-card { padding:14px !important; }

            /* ── Dashboard ── */
            .dash-grid { grid-template-columns:1fr !important; }
            .welcome-card { padding:16px !important; }

            /* ── Charts ── */
            .chart-grid { grid-template-columns:1fr !important; }
            .chart-card { min-height:280px !important; }

            /* ── Admin Log ── */
            .log-filters { flex-direction:column !important; gap:8px !important; }
            .log-filters select, .log-filters input { width:100% !important; }

            /* ── Login page ── */
            .login-card { width:95vw !important; max-width:95vw !important; padding:24px !important; }

            /* ── Log/code textareas ── */
            #ccLog, .sp-guide-pre, #exportLog, .panel-output, textarea[readonly] {
                font-size:10px !important; min-height:150px;
            }

            /* ── File Structure panels ── */
            .panel-header { flex-direction:column !important; gap:8px !important; align-items:flex-start !important; }
            .panel-title { font-size:14px !important; }

            /* ── Generic helpers ── */
            [style*="display:flex"], [style*="display: flex"] { flex-wrap:wrap !important; }
            pre, code { font-size:11px !important; word-break:break-all; }
        }

        /* ── RESPONSIVE: Small mobile (≤480px) ──────── */
        @media (max-width: 480px) {
            .main-content { padding: 8px; }
            .page-title { font-size:14px !important; }
            .sidebar { width:85vw !important; }

            /* Stats: 1 col on tiny screens */
            .stats-row, .stat-grid, .stats-grid { grid-template-columns:1fr !important; }

            /* Even smaller text */
            th, td { font-size:11px !important; padding:6px 8px !important; }
            .btn { font-size:11px !important; padding:6px 12px !important; }

            /* Tab pills: smaller */
            .nav-pill { padding:6px 10px !important; font-size:11px !important; }
        }
    </style>
    @stack('styles')
    @if(!empty($__cfg['custom_css']))
    <style>{!! $__cfg['custom_css'] !!}</style>
    @endif
    @if(!empty($__cfg['custom_head_html']))
    {!! $__cfg['custom_head_html'] !!}
    @endif
</head>
<body>
    <div class="admin-wrapper">
        <div class="sidebar-overlay" id="sidebarOverlay"></div>
        @include('admin.partials.menu_left')
        <div class="main-wrapper">
            @include('admin.partials.menu_upper')
            <main class="main-content">
                @yield('content')
            </main>
            @include('admin.partials.menu_footer')
        </div>
    </div>
    <script>
        // Sidebar toggle for mobile
        function openSidebar() {
            document.querySelector('.sidebar').classList.add('show');
            document.getElementById('sidebarOverlay').classList.add('show');
            document.body.style.overflow = 'hidden';
        }
        function closeSidebar() {
            document.querySelector('.sidebar').classList.remove('show');
            document.getElementById('sidebarOverlay').classList.remove('show');
            document.body.style.overflow = '';
        }
        document.getElementById('sidebarOverlay').addEventListener('click', closeSidebar);

        // Close sidebar on nav click (mobile)
        document.querySelectorAll('.nav-link:not([onclick]), .nav-sublink').forEach(function(link) {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 1024) closeSidebar();
            });
        });

        // Submenu toggle
        document.querySelectorAll('.nav-link.has-submenu').forEach(function(link) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const submenu = this.nextElementSibling;
                this.classList.toggle('expanded');
                submenu.classList.toggle('show');
            });
        });

        // Wrap bare tables in responsive container
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.main-content table').forEach(function(tbl) {
                if (!tbl.closest('.table-responsive') && !tbl.closest('.table-wrap') && !tbl.closest('.sp-table') && !tbl.closest('pre')) {
                    const wrap = document.createElement('div');
                    wrap.className = 'table-responsive';
                    wrap.style.cssText = 'overflow-x:auto;-webkit-overflow-scrolling:touch;';
                    tbl.parentNode.insertBefore(wrap, tbl);
                    wrap.appendChild(tbl);
                }
            });
        });
    </script>
    <script src="{{ asset('js/components.js') }}"></script>
    @stack('scripts')
</body>
</html>
