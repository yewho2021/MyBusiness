# P15-P26: Complete CSS Variable Migration (All Remaining Views)

## Problem
After P14, 1,811 hardcoded hex colors remained across 55 views (71% of all
color references). Theme changes in Configuration only affected 29% of the UI.

## Solution
Systematic migration of all remaining views with context-aware handling:
- CSS/style contexts: all hex colors → CSS variables
- PHP fallbacks (login/2fa): kept as hex (needed for inline style interpolation)
- JavaScript ECharts configs (charts page): kept as hex (CSS vars not supported)
- JS element.style assignments: migrated to var() (works in inline CSS)

## Migration Stats
- Views migrated: 55 (all except query.blade.php from P14)
- Hardcoded removed: 1,720 colors → CSS variables
- Intentionally kept: 91 (70 charts JS + 21 auth PHP fallbacks)
- CSS variable references: 2,105 total

## Context Rules Applied
- style="color: #hex" → style="color: var(--name)" ✅
- element.style.color = '#hex' → element.style.color = 'var(--name)' ✅
- $var = $cfg['key'] ?? '#hex' → KEPT AS HEX (PHP interpolation) ⚠️
- ECharts {color: '#hex'} → KEPT AS HEX (charting library) ⚠️

## Files Changed
55 blade files in resources/views/admin/

## Rollback Safety
Safe — CSS variables have fallback defaults. No functional changes.
